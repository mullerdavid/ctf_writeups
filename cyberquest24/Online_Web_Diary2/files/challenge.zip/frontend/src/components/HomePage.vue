<template>
  <div class="container mx-auto px-4">
    <h2 class="text-3xl font-bold mb-6">Welcome to Your Notes</h2>
    <div v-if="loading" class="text-gray-700">Loading...</div>
    <div v-else>
      <div v-if="Object.keys(notes).length > 0">
        <h3 class="text-xl font-semibold mb-4">Your Notes</h3>
        <ul>
          <li v-for="(note, id) in notes" :key="id" class="mb-2">
            <router-link :to="{ name: 'NoteDetail', params: { id: id }}" class="text-blue-500 hover:underline">{{ note }}</router-link>
          </li>
        </ul>
      </div>
      <div v-else>
        <p class="text-gray-700">No notes found.</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import { BASE_URL } from '@/config';

export default {
  name: 'HomePage',
  data() {
    return {
      loading: true,
      notes: {}
    };
  },
  mounted() {
    this.fetchNotes();
  },
  methods: {
    fetchNotes() {
      const token = localStorage.getItem('token');
      if (!token) {
        this.$router.push('/login');
        return;
      }

      axios.get(`${BASE_URL}/notes/list`, {
        headers: {
          Authorization: token
        }
      })
      .then(response => {
        this.notes = response.data;
        this.loading = false;
      })
      .catch(error => {
        console.error('Error fetching notes:', error);
      });
    }
  }
};
</script>

<style scoped>
</style>
