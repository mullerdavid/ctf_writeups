<template>
  <nav class="bg-gray-100 shadow-lg">
    <div class="container mx-auto px-4">
      <div class="flex justify-between items-center py-4">
        <router-link class="text-xl font-bold text-gray-800" to="/">Your Notes</router-link>
        <button class="block lg:hidden focus:outline-none" @click="toggleMenu">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
          </svg>
        </button>
        <div :class="{ 'hidden': !isMenuOpen }" class="w-full flex-grow lg:flex lg:items-center lg:w-auto">
          <ul class="lg:flex justify-end items-center mt-4 lg:mt-0">
            <li>
              <router-link class="block px-4 py-2 text-gray-700 hover:text-blue-500" to="/notes/create">Create Note</router-link>
            </li>
            <li>
              <router-link class="block px-4 py-2 text-gray-700 hover:text-blue-500" to="/login">Login</router-link>
            </li>
            <li>
              <router-link class="block px-4 py-2 text-gray-700 hover:text-blue-500" to="/register">Register</router-link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  name: 'MenuComponent',
  data() {
    return {
      isMenuOpen: false
    };
  },
  methods: {
    toggleMenu() {
      this.isMenuOpen = !this.isMenuOpen;
    }
  }
};
</script>
