<template>
    <div class="container mx-auto px-4">
        <h2 class="text-3xl font-bold mb-6">Create Note</h2>
        <div class="flex flex-wrap -mx-4">
            <div class="w-full md:w-1/2 px-4">
                <form @submit.prevent="createNote" class="bg-white shadow-lg rounded-lg p-6">
                    <div class="mb-6">
                        <label for="title" class="block text-gray-700 font-semibold mb-2">Title:</label>
                        <input type="text" id="title" v-model="title"
                            class="form-input w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>
                    <div class="mb-6">
                        <label for="content" class="block text-gray-700 font-semibold mb-2">Content:</label>
                        <textarea id="content" v-model="content"
                            class="form-textarea w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                            rows="6"></textarea>
                    </div>
                    <button type="submit"
                        class="btn btn-primary w-full rounded-lg py-3 px-4 text-white font-semibold hover:bg-indigo-600">Save</button>
                </form>
                <p v-if="error" class="mt-3 text-red-500">{{ error }}</p>
            </div>
            <div class="w-full md:w-1/2 px-4">
                <div class="bg-white shadow-lg rounded-lg p-6">
                    <h4 class="text-xl font-semibold mb-4">Preview</h4>
                    <div v-html="markdownContent" class="markdown-preview"></div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
import { BASE_URL } from '@/config';
import { marked } from 'marked';

export default {
    name: 'CreateNotes',
    data() {
        return {
            title: '',
            content: '',
            error: '',
            markdownContent: ''
        };
    },
    methods: {
        createNote() {
            const token = localStorage.getItem('token');
            if (!token) {
                this.$router.push('/login');
                return;
            }

            axios.post(`${BASE_URL}/notes/create`, {
                title: this.title,
                content: this.content
            }, {
                headers: {
                    Authorization: token
                }
            })
                .then(response => {
                    if (response.status === 201) {
                        this.$router.push('/');
                    } else {
                        this.error = 'An error occurred. Please try again later.';
                    }
                })
                .catch(error => {
                    if (error.response && error.response.data) {
                        this.error = error.response.data;
                    } else {
                        this.error = 'An error occurred. Please try again later.';
                    }
                });
        },
        updatePreview() {
            this.markdownContent = marked(this.content);
        }
    },
    watch: {
        content: {
            handler() {
                this.updatePreview();
            },
            immediate: true
        }
    }
};
</script>

<style scoped>
.btn-primary {
    background-color: #4a90e2;
}

.btn-primary:hover {
    background-color: #2e71c8;
}
</style>