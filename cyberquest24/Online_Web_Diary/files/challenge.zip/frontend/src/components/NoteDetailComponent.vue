<template>
    <div class="container mx-auto px-4">
      <h2 class="text-3xl font-bold mb-6">Note PDF</h2>
      <div v-if="loading" class="text-gray-700">Loading...</div>
      <div v-else>
        <iframe :src="pdfUrl" class="w-full h-96" frameborder="0"></iframe>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  import { BASE_URL } from '@/config';
  
  export default {
    name: 'NotePdfComponent',
    data() {
      return {
        loading: true,
        pdfUrl: ''
      };
    },
    mounted() {
      this.fetchPdfUrl();
    },
    methods: {
      fetchPdfUrl() {
        const token = localStorage.getItem('token');
        if (!token) {
          this.$router.push('/login');
          return;
        }
  
        const noteId = this.$route.params.id;
        axios.get(`${BASE_URL}/notes/render?noteID=${noteId}`, {
          headers: {
            Authorization: token
          },
          responseType: 'blob'
        })
        .then(response => {
          const pdfBlob = new Blob([response.data], { type: 'application/pdf' });
          this.pdfUrl = URL.createObjectURL(pdfBlob);
          this.loading = false;
        })
        .catch(error => {
          console.error('Error fetching PDF:', error);
        });
      }
    }
  };
  </script>
  
  <style>
  </style>
  