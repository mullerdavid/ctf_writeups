import { createRouter, createWebHashHistory } from 'vue-router'
import HomePage from './components/HomePage.vue';
import LoginPage from './components/LoginPage.vue';
import RegisterPage from './components/RegisterPage.vue';
import CreateNotePage from './components/CreateNotePage.vue';
import NoteDetailComponent from './components/NoteDetailComponent.vue';

const routes = [
    { path: '/', component: HomePage },
    { path: '/login', component: LoginPage },
    { path: '/register', component: RegisterPage },
    { path: '/notes/create', component: CreateNotePage },
    {
        path: '/notes/:id',
        name: 'NoteDetail',
        component: NoteDetailComponent
    },
];

const router = createRouter({
    history: createWebHashHistory(),
    routes,
});

export default router;