<?php
    session_start();

    $dbFilePath = 'data/database.db';

    function createDatabase($dbFilePath) {
        try {
            $db = new PDO('sqlite:' . $dbFilePath);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $createTableQuery = "
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    password TEXT NOT NULL
                );
            ";
            $db->exec($createTableQuery);

            $users = [
                ['username' => 'NCarlsen', 'password' => '123456789'],
                ['username' => 'EEdward', 'password' => 'SuperSecretPassword'],
                ['username' => 'DFord', 'password' => 'R4pt0r'],
                ['username' => 'MBranagh', 'password' => 'Poirot'],
                ['username' => 'RPhillips', 'password' => 'W4sch1ngM4ch1n3'],
                ['username' => 'GScott', 'password' => 'Dundies'],
                ['username' => 'LSKennedy', 'password' => 'R3s1d3nt3v1l'],
            ];

            $insertUserQuery = $db->prepare("
                INSERT INTO users (username, password) VALUES (:username, :password);
            ");

            foreach ($users as $user) {
                $insertUserQuery->execute($user);
            }

            return $db;
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
            die();
        }
    }

    if (!file_exists($dbFilePath)) {
        $db = createDatabase($dbFilePath);
    } else {
        try {
            $db = new PDO('sqlite:' . $dbFilePath);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
            die();
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Vulnerable to SQL injection
        $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
        $result = $db->query($query);
        
        if ($result) {
            $user = $result->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $_SESSION['username'] = $user['username'];
                $_SESSION['loggedin'] = 1;
                header('Location: ./pages/main.php');
                exit;
            } else {
                $res = "Invalid username or password";
            }
        } else {
            $res = "Error executing query";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Raccoon City Police Department - Login</title>
    <link rel="stylesheet" href="assets/style/style.css" />
    <link rel="icon"href="/assets/pictures/badge.png">
  </head>
  <body>
    <div class="login-container">
      <h2>Raccoon City Police Department</h2>
      <form action="/index.php" method="post">
        <div class="input-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" required />
        </div>
        <div class="input-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required />
        </div>
        <div class="submit-btn">
          <button type="submit">Login</button>
        </div>
      </form>
    </div>
  </body>
</html>
