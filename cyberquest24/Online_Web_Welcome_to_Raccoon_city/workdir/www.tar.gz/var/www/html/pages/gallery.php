<?php 
    session_start();

    if ($_SESSION["loggedin"] !== 1 || !isset($_SESSION["loggedin"])) {
        header('Location: ../index.php');
        exit;
    }

    // Vulnerable Directory Traversal handling
    if (isset($_GET['file'])) {
        $file = $_GET['file'];

        // Allow traversal and construct the full file path
        $path = realpath($file);

        // Check if the file exists
        if (file_exists($path)) {

            // Get the file's MIME type to determine how to serve it
            $mime_type = mime_content_type($path);

            // Serve the file differently depending on its MIME type
            header("Content-Type: $mime_type");
            header("Content-Disposition: inline; filename=\"" . basename($path) . "\"");

            // Read and serve the file content
            include($path);
            exit;
        } else {
            echo "Select a file from the gallery to view.";
        }
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raccoon City Police Department - Gallery</title>
    <link rel="icon" href="/assets/pictures/badge.png">
    <link rel="stylesheet" href="/assets/style/gallery.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="/pages/main.php">Home</a></li>
                <li><a href="/pages/gallery.php">Gallery</a></li>
                <li><a href="/pages/upload.php">Cases</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="gallery-section">
            <h2>Our Brave Officers</h2>
            <div class="gallery-row">
                <a href="?file=chris.jpg"><img src="/assets/pictures/chris.jpg" alt="Chris Redfield"></a>
                <a href="?file=irons.jpg"><img src="/assets/pictures/irons.jpg" alt="Chief Irons"></a>
                <a href="?file=jill.jpg"><img src="/assets/pictures/jill.jpg" alt="Jill Valentine"></a>
                <a href="?file=marvin.jpg"><img src="/assets/pictures/marvin.jpg" alt="Marvin Branagh"></a>
                <a href="?file=leon.jpg"><img src="/assets/pictures/leon.jpg" alt="Leon S Kennedy"></a>
            </div>

            <h2>Our Department</h2>
            <div class="gallery-row">
                <a href="?file=racoon1.jpg"><img src="/assets/pictures/racoon1.jpg" alt="RPD"></a>
                <a href="?file=racoon2.jpg"><img src="/assets/pictures/racoon2.jpg" alt="RPD"></a>
                <a href="?file=racoon3.png"><img src="/assets/pictures/racoon3.png" alt="RPD"></a>
            </div>

            <h2>Welcoming Our Rookie</h2>
            <div class="gallery-row">
                <a href="?file=rookie.jpg"><img src="/assets/pictures/rookie.jpg" alt="Welcoming Leon"></a>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Raccoon City Police Department</p>
    </footer>

</body>
</html>

