<?php 

    session_start();

    error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);

    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== 1) {
        header('Location: ../index.php');
        exit;
    }

    $response = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $target_dir = "/var/cases/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        $check = getimagesize($_FILES["file"]["tmp_name"]);
        if($check !== false) {
            $response = "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            $response = "File is not an image.";
            $uploadOk = 0;
        }

        if (file_exists($target_file)) {
            $response = "Sorry, file already exists.";
            $uploadOk = 0;
        }

        if ($_FILES["file"]["size"] > 500000) {
            $response = "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            $response = "Sorry, only JPG, JPEG, PNG files are allowed.";
            $uploadOk = 0;
        }

        if ($response == "" && $uploadOk == 0) {
            $response = "Sorry, your file was not uploaded.";
        } else {
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file) && chmod($target_file, 0777)) {
                $response = "The file ". htmlspecialchars( basename( $_FILES["file"]["name"])). " has been uploaded.";
            } else {
                $response = "Sorry, there was an error uploading your file.";
            }
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raccoon City Police Department</title>
    <link rel="icon"href="/assets/pictures/badge.png">
    <link rel="stylesheet" href="/assets/style/upload.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="/pages/main.php">Home</a></li>
                <li><a href="/pages/gallery.php">Gallery</a></li>
                <li><a href="/pages/upload.php">Cases</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="upload-section">
            <h2>Upload Files</h2>
            <p>Please upload crime scene pictures related to ongoing cases or evidence.</p>
            <form action="upload.php" method="post" enctype="multipart/form-data">
                <div class="input-group">
                    <label for="file">Choose a file:</label>
                    <input type="file" id="file" name="file" required>
                </div>
                <p id="res"></p>
                <button type="submit">Upload</button>
            </form>
        </section>
    </main>

    <footer>
        <p>2024 Raccoon City Police Department</p>
    </footer>

    <script>
        document.getElementById("res").innerText = "<?php echo $response; ?>";
    </script>
</body>
</html>