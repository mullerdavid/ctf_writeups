<?php 

    session_start();

    if($_SESSION["loggedin"] !== 1 || !isset($_SESSION["loggedin"])) {
        header('Location: ../index.php');
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raccoon City Police Department</title>
    <link rel="icon"href="/assets/pictures/badge.png">
    <link rel="stylesheet" href="/assets/style/main.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="/pages/main.php">Home</a></li>
                <li><a href="/pages/gallery.php">Gallery</a></li>
                <li><a href="/pages/upload.php">Cases</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Welcome to Raccoon City Police Department</h2>
            <p>This is the official site of the Raccoon City Police Department. Our mission is to protect and serve the community, keeping the streets safe and upholding justice.</p>
            <p>Navigate through our gallery and learn about our active and past cases to get a better understanding of what we do to maintain peace in the city.</p>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Raccoon City Police Department</p>
    </footer>
</body>
</html>