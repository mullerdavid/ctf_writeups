<?php

    session_start();

    if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== 1){
        header('Location: ../../index.php');
        exit;
    }


    error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);

    if (isset($_POST['name'])) {

        $xml = simplexml_load_file('../data/tasks.xml');
        $results = $xml->xpath("/users/user[name='{$_POST['name']}']/task");

        if ($results !== false && count($results) > 0) {
            $task = $results[0];
            $task = "Task: $task";
        }
        else {
            $task = "No task found for given user";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="tasks.css">
    <link rel="icon" type="image/x-icon" href="helmet.svg">
    <title>Blu Tasks</title>
</head>
<body>
    <div class="container">
        <h1>BLU tasks</h1>
        <form method="POST" action="tasks.php">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" placeholder="Enter your name....">
            <input type="submit" value="Show task">
        </form>
        <div>
            <p id="result"></p>
        </div>
    </div>
    <script>
        document.getElementById('result').innerText = '<?php echo $task ?? ""; ?>';
    </script>
</body>
</html>