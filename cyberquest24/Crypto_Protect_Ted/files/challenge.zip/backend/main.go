package main

import (
	"encoding/hex"
	"fmt"
	"net"
	"os"
	"strings"

	"crypto/aes"
)

const (
	secretKey = "redactedforctf:)"
)

const finishingMessage = "redacted"

func decryptAES(ciphertext []byte) ([]byte, error) {
	block, err := aes.NewCipher([]byte(secretKey))
	if err != nil {
		return nil, err
	}

	// ECB mode does not require an IV
	if len(ciphertext)%block.BlockSize() != 0 {
		return nil, fmt.Errorf("ciphertext is not a multiple of the block size")
	}

	decrypted := make([]byte, len(ciphertext))
	for bs, be := 0, block.BlockSize(); bs < len(ciphertext); bs, be = bs+block.BlockSize(), be+block.BlockSize() {
		block.Decrypt(decrypted[bs:be], ciphertext[bs:be])
	}

	return decrypted, nil
}

func handleConnection(conn net.Conn) {
	defer conn.Close()

	conn.Write([]byte("Please provide a hex input of what you want to decrypt: "))

	buffer := make([]byte, 1024)

	n, err := conn.Read(buffer)
	if err != nil {
		fmt.Println("Error reading from connection:", err)
		return
	}

	input := strings.TrimSpace(string(buffer[:n]))
	if input == "" {
		conn.Write([]byte("Please provide a hex input\n"))
		return
	}

	ciphertext, err := hex.DecodeString(input)
	if err != nil {
		conn.Write([]byte("Invalid hex input\n"))
		return
	}

	decrypted, err := decryptAES(ciphertext)
	if err != nil {
		conn.Write([]byte("Decryption failed\n"))
		return
	}

	decryptedString := string(decrypted)

	if decryptedString == secretKey {
		conn.Write([]byte(finishingMessage))
	} else {
		conn.Write([]byte(decryptedString))
	}

	conn.Write([]byte("\n"))
}

func main() {

	port := os.Getenv("BACKEND_PORT")
	if port == "" {
		port = "1337"
	}

	ln, err := net.Listen("tcp", ":"+port)
	if err != nil {
		fmt.Println("Error starting TCP server:", err)
		os.Exit(1)
	}
	defer ln.Close()

	fmt.Println("TCP server is listening on port", port)

	for {
		conn, err := ln.Accept()
		if err != nil {
			fmt.Println("Error accepting connection:", err)
			continue
		}
		go handleConnection(conn)
	}
}
