package main

const flag = "flag{this_is_a_fake_flag}"
const flagText = "Congratulations on solving the challenge! If you solve this challenge on the remote host, you get some actual information. But here is your flag: " + flag
