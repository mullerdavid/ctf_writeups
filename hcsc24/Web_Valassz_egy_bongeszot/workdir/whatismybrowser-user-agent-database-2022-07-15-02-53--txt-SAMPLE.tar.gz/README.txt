# WhatIsMyBrowser.com - User Agent Database

This user agent database dump is provided by WhatIsMyBrowser.com

See the following URL for a description, instructions and legal information.

https://developers.whatismybrowser.com/useragents/database/

----

whatismybrowser.com
