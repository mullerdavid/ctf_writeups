#!/bin/sh

chmod +x assets/create_message_db.sh
cd assets
./create_message_db.sh
cd ..

docker build -t ctf-prequels-revenge:latest .
docker rm -f ctf-prequels-revenge:latest; docker run --name ctf-prequels-revenge -it --rm -p 3117:3117 -e CHALLENGE_PORT=3117 ctf-prequels-revenge:latest
