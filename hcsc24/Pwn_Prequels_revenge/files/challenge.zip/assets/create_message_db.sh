#!/bin/sh

sqlite3 messages.db <<SQL
CREATE TABLE messages (name TEXT, message TEXT);
INSERT INTO messages VALUES ('Alice', 'Hello Alice!');
INSERT INTO messages VALUES ('Bob', 'Hello Bob!');
INSERT INTO messages VALUES ('Eve', 'Hello Eve!');
CREATE TABLE flag (flag TEXT);
INSERT INTO flag VALUES ('HCSC24{this_is_a_fake_flag}');
SQL
