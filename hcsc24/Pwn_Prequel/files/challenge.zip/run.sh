#!/bin/sh

chmod +x assets/create_message_db.sh
cd assets
./create_message_db.sh
cp messages_debug.db messages.db
cd ..

docker build -t ctf-prequel:latest .
docker rm -f ctf-prequel:latest; docker run --name ctf-prequel -it --rm -p 3117:3117 -e CHALLENGE_PORT=3117 ctf-prequel:latest
