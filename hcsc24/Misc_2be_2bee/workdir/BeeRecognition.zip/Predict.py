import os
import tensorflow as tf
import numpy as np

from skimage import io, transform

IMAGE_SIZE = (100, 100)
list_lbl = ['Italian honey bee', '1 Mixed local stock 2', 'VSH Italian honey bee',
            'Russian honey bee', 'Carniolan honey bee', 'Western honey bee']


# Upload the saved model
cnn_model = tf.keras.models.load_model(os.path.join('results', 'FinalModel.h5'))


def load_img(file, target_size):
    img = io.imread(file)
    img = transform.resize(img, target_size, mode='reflect')
    return img[:, :, :3]


def predict(file):
    img = load_img(file, target_size=IMAGE_SIZE)
    img = np.expand_dims(img, axis=0)
    prob_array = cnn_model.predict(img)
    result = np.where(prob_array[0] == np.amax(prob_array[0]))[0][0]
    return list_lbl[result]





if __name__ == '__main__':
    file_path = r"c:\Temp\ctf\misc\images\_NiKzeWnFYUf6alYF-0bmUQL4J_WU7HwrjLEidRm5OhZuEa3w_AS-Zyms3-ak4YXOSY7.png"
    preds = predict(file_path)
    print('[PREDICTED CLASSES]: {}'.format(preds))
