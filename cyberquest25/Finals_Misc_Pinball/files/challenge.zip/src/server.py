from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict

from fastapi import FastAPI, Request, Response
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
from pydantic import BaseModel
from uuid import uuid4

from color_predictor import ColorService


BOARD_COLS = 10
BOARD_ROWS = 14
CELL_SIZE = 32
BOARD_WIDTH = BOARD_COLS * CELL_SIZE
BOARD_HEIGHT = BOARD_ROWS * CELL_SIZE
RADIUS = max(8, CELL_SIZE // 2 - 2)
MIN_ANGLE_DEG = 10
MAX_ANGLE_DEG = 170
SPEED = 700.0
SHOT_COOLDOWN_SEC = 1
SESSION_LIMIT_SEC = 60
COLORS = ["#ff595e", "#ffca3a", "#8ac926", "#1982c4", "#6a4c93"]


def clamp_angle_deg(angle_deg: float) -> float:
    return max(MIN_ANGLE_DEG, min(MAX_ANGLE_DEG, angle_deg))


@dataclass
class Bubble:
    color: str


@dataclass
class GameState:
    grid: List[List[Optional[Bubble]]] = field(default_factory=list)
    prev_color: Optional[str] = None
    score: int = 0

    def __post_init__(self):
        if not self.grid:

            rows = 4
            for r in range(BOARD_ROWS):
                row: List[Optional[Bubble]] = []
                for c in range(BOARD_COLS):
                    if r < rows and random.random() < 0.7:
                        row.append(Bubble(color=random.choice(COLORS)))
                    else:
                        row.append(None)
                self.grid.append(row)


@dataclass
class Session:
    state: GameState = field(default_factory=GameState)
    last_shot_at: float = 0.0
    started_at: float = field(default_factory=time.time)


def session_time_remaining(sess: Session) -> float:
    now = time.time()
    return max(0.0, SESSION_LIMIT_SEC - (now - sess.started_at))


def grid_to_pixel(c: int, r: int) -> Tuple[float, float]:
    x = c * CELL_SIZE + CELL_SIZE / 2
    y = r * CELL_SIZE + CELL_SIZE / 2
    return (x, y)


def pixel_to_grid(x: float, y: float) -> Tuple[int, int]:
    c = int(x // CELL_SIZE)
    r = int(y // CELL_SIZE)
    return (max(0, min(BOARD_COLS - 1, c)), max(0, min(BOARD_ROWS - 1, r)))


def snap_to_grid(x: float, y: float) -> Tuple[int, int]:
    c, r = pixel_to_grid(x, y)

    return (c, r)


def neighbors(c: int, r: int) -> List[Tuple[int, int]]:
    ns = []
    for dc, dr in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nc, nr = c + dc, r + dr
        if 0 <= nc < BOARD_COLS and 0 <= nr < BOARD_ROWS:
            ns.append((nc, nr))
    return ns


def find_cluster(
    grid: List[List[Optional[Bubble]]], start: Tuple[int, int]
) -> List[Tuple[int, int]]:
    c0, r0 = start
    if grid[r0][c0] is None:
        return []
    target_color = grid[r0][c0].color
    seen = set([start])
    stack = [start]
    cluster = []
    while stack:
        c, r = stack.pop()
        cluster.append((c, r))
        for nc, nr in neighbors(c, r):
            b = grid[nr][nc]
            if b is not None and b.color == target_color and (nc, nr) not in seen:
                seen.add((nc, nr))
                stack.append((nc, nr))
    return cluster


def remove_floating(grid: List[List[Optional[Bubble]]]) -> int:

    attached = set()
    stack = [(c, 0) for c in range(BOARD_COLS) if grid[0][c] is not None]
    while stack:
        c, r = stack.pop()
        if (c, r) in attached:
            continue
        attached.add((c, r))
        for nc, nr in neighbors(c, r):
            if grid[nr][nc] is not None and (nc, nr) not in attached:
                stack.append((nc, nr))

    removed = 0
    for r in range(BOARD_ROWS):
        for c in range(BOARD_COLS):
            if grid[r][c] is not None and (c, r) not in attached:
                grid[r][c] = None
                removed += 1
    return removed


def simulate_shot(
    grid: List[List[Optional[Bubble]]], angle_deg: float, color: str, gs: GameState
) -> Dict:

    angle_deg = clamp_angle_deg(angle_deg)
    angle_rad = math.radians(angle_deg)

    x = BOARD_WIDTH / 2
    y = BOARD_HEIGHT - RADIUS - 2
    vx = math.cos(angle_rad)
    vy = -math.sin(angle_rad)

    dt = 0.006
    max_steps = int(12.0 / dt)

    damping = math.radians(0.35)

    path: List[Tuple[float, float]] = [(x, y)]

    for _ in range(max_steps):
        nx = x + vx * SPEED * dt
        ny = y + vy * SPEED * dt

        if nx < RADIUS:
            nx = RADIUS
            vx = abs(vx)

            cur_angle = math.atan2(-vy, vx)
            cur_angle = max(
                math.radians(MIN_ANGLE_DEG), min(math.radians(MAX_ANGLE_DEG), cur_angle)
            )
            cur_angle = cur_angle * (1 - 0.0)

            cur_angle += damping
            vx, vy = math.cos(cur_angle), -math.sin(cur_angle)
        elif nx > BOARD_WIDTH - RADIUS:
            nx = BOARD_WIDTH - RADIUS
            vx = -abs(vx)
            cur_angle = math.atan2(-vy, vx)
            cur_angle = max(
                math.radians(MIN_ANGLE_DEG), min(math.radians(MAX_ANGLE_DEG), cur_angle)
            )
            cur_angle -= damping
            vx, vy = math.cos(cur_angle), -math.sin(cur_angle)

        if ny < RADIUS:
            ny = RADIUS

            gc, gr = snap_to_grid(nx, ny)
            placed = place_bubble(grid, gc, gr, color, gs)
            return placed

        gc, gr = pixel_to_grid(nx, ny)
        hit = False
        for rc in range(max(0, gc - 1), min(BOARD_COLS, gc + 2)):
            for rr in range(max(0, gr - 1), min(BOARD_ROWS, gr + 2)):
                if grid[rr][rc] is not None:
                    cx, cy = grid_to_pixel(rc, rr)
                    dx = nx - cx
                    dy = ny - cy
                    dist2 = dx * dx + dy * dy
                    if dist2 <= (2 * RADIUS) ** 2 - 1e-3:

                        hit = True
                        break
            if hit:
                break

        if hit:
            sc, sr = snap_to_grid(nx, ny)
            placed = place_bubble(grid, sc, sr, color, gs)
            return placed

        x, y = nx, ny
        path.append((x, y))

    sc, sr = snap_to_grid(x, y)
    placed = place_bubble(grid, sc, sr, color, gs)
    return placed


def place_bubble(
    grid: List[List[Optional[Bubble]]], c: int, r: int, color: str, gs: GameState
) -> Dict:

    if grid[r][c] is not None:
        for radius in range(1, 3):
            for dc in range(-radius, radius + 1):
                for dr in range(-radius, radius + 1):
                    nc, nr = c + dc, r + dr
                    if (
                        0 <= nc < BOARD_COLS
                        and 0 <= nr < BOARD_ROWS
                        and grid[nr][nc] is None
                    ):
                        c, r = nc, nr
                        break
                else:
                    continue
                break

    grid[r][c] = Bubble(color=color)

    cluster = find_cluster(grid, (c, r))
    popped = 0
    if len(cluster) >= 3:
        for cc, rr in cluster:
            grid[rr][cc] = None
            popped += 1

        popped += remove_floating(grid)

    gs.score += popped

    dead = (r >= BOARD_ROWS - 1) or all(
        cell is not None for row in grid for cell in row
    )
    flag = None
    if gs.score >= 70:
        flag = "CQ25{fake_flag}"
    if dead:
        new_state = GameState()
        gs.grid = new_state.grid

        px, py = grid_to_pixel(c, r)
        return {
            "final": {"x": px, "y": py, "col": c, "row": r},
            "popped": popped,
            "board": export_board(gs.grid),
            "prevColor": gs.prev_color,
            "score": gs.score,
            "dead": True,
            "flag": flag,
        }

    px, py = grid_to_pixel(c, r)
    return {
        "final": {"x": px, "y": py, "col": c, "row": r},
        "popped": popped,
        "board": export_board(grid),
        "prevColor": gs.prev_color,
        "score": gs.score,
    }


def export_board(grid: List[List[Optional[Bubble]]]) -> List[List[Optional[str]]]:
    out: List[List[Optional[str]]] = []
    for r in range(BOARD_ROWS):
        row: List[Optional[str]] = []
        for c in range(BOARD_COLS):
            row.append(grid[r][c].color if grid[r][c] is not None else None)
        out.append(row)
    return out


class ShootRequest(BaseModel):
    angleDeg: float


app = FastAPI()

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


sessions: Dict[str, Session] = {}

color_service = ColorService(out_classes=len(COLORS))


def current_color() -> str:
    idx = color_service.predict_index(time.time(), window_seconds=2)
    return COLORS[idx]


def get_session(request: Request, response: Response) -> Session:
    sid = request.cookies.get("sid")
    if not sid or sid not in sessions:
        sid = uuid4().hex
        sessions[sid] = Session()

        response.set_cookie(key="sid", value=sid, httponly=True, samesite="lax")
    return sessions[sid]


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "board_width": BOARD_WIDTH,
            "board_height": BOARD_HEIGHT,
            "cell_size": CELL_SIZE,
            "colors": COLORS,
        },
    )


@app.get("/state")
async def get_state(request: Request, response: Response):
    session = get_session(request, response)
    return {
        "board": export_board(session.state.grid),
        "boardWidth": BOARD_WIDTH,
        "boardHeight": BOARD_HEIGHT,
        "cellSize": CELL_SIZE,
        "radius": RADIUS,
        "prevColor": session.state.prev_color,
        "minAngle": MIN_ANGLE_DEG,
        "maxAngle": MAX_ANGLE_DEG,
        "speed": SPEED,
        "score": session.state.score,
        "timeRemaining": session_time_remaining(session),
    }


@app.post("/shoot")
async def shoot(req: ShootRequest, request: Request, response: Response):
    session = get_session(request, response)
    now = time.time()

    if now - session.started_at >= SESSION_LIMIT_SEC:

        timed_out = True
        session.state = GameState()
        session.started_at = time.time()
        session.last_shot_at = 0.0
        return {
            "timedOut": timed_out,
            "board": export_board(session.state.grid),
            "prevColor": session.state.prev_color,
            "score": 0,
            "timeRemaining": session_time_remaining(session),
        }
    if now - session.last_shot_at < SHOT_COOLDOWN_SEC:
        retry = int((SHOT_COOLDOWN_SEC - (now - session.last_shot_at)) * 1000)
        return {
            "rateLimited": True,
            "retryAfterMs": max(0, retry),
            "score": session.state.score,
            "prevColor": session.state.prev_color,
        }
    session.last_shot_at = now

    col = current_color()
    result = simulate_shot(session.state.grid, req.angleDeg, col, session.state)
    session.state.prev_color = col
    if session.state.score >= 70:
        result.setdefault("flag", "CQ25{fake_flag}")
    return result


@app.post("/reset")
async def reset(request: Request, response: Response):
    session = get_session(request, response)
    session.state = GameState()
    session.last_shot_at = 0.0
    return {
        "board": export_board(session.state.grid),
        "prevColor": session.state.prev_color,
        "score": session.state.score,
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("src.server:app", host="0.0.0.0", port=8000, reload=True)
