import time
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class ColorPredictor(nn.Module):
    def __init__(self, out_classes: int = 5):
        super().__init__()
        self.fc1 = nn.Linear(1, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, out_classes)
        torch.manual_seed(42)
        for layer in [self.fc1, self.fc2, self.fc3]:
            nn.init.xavier_uniform_(layer.weight)
            nn.init.uniform_(layer.bias, -0.1, 0.1)

    def forward(self, x):
        h1 = torch.sin(self.fc1(x))
        h2 = torch.cos(self.fc2(h1))
        x = torch.tanh(h1 + h2) + 0.1 * torch.sin(5 * h2)
        out = self.fc3(x)
        return F.softmax(out, dim=-1)


class ColorService:
    def __init__(self, out_classes: int = 5, model_path: Optional[Path] = None):
        self.out_classes = out_classes
        self.model_path = (
            Path(model_path)
            if model_path is not None
            else Path(__file__).with_name("color_model.pt")
        )
        self._model = None
        self._load_or_build()

    def _load_or_build(self):
        if self.model_path.exists():
            self._model = torch.jit.load(str(self.model_path))
            self._model.eval()
        else:
            model = ColorPredictor(self.out_classes)
            scripted = torch.jit.script(model)
            scripted.save(str(self.model_path))
            self._model = scripted
            self._model.eval()

    def predict_index(self, t: Optional[float] = None, window_seconds: int = 2) -> int:
        if t is None:
            t = time.time()
        tick = int(t // window_seconds) % 1000
        x_val = torch.tensor([[tick]], dtype=torch.float32)
        with torch.no_grad():
            probs = self._model(x_val)
        idx = int(torch.argmax(probs, dim=1).item())
        return idx % self.out_classes
