#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <ctype.h>

#define MAX_SHEETS 100
#define MAX_COLS 4
#define MAX_ROWS 8

struct Cell {
    char *data;
    char raw_data[16];
};

struct Sheet {
    char name[9];
    struct Cell cells[MAX_ROWS][MAX_COLS];
    int in_use;
};

struct Sheet sheets[MAX_SHEETS];

void* sheet_malloc(struct Sheet* s, size_t size) {
    char* ptr = calloc(1, size);
    return ptr;
}

void sheet_free(struct Sheet* s, void* ptr) {
    free(ptr);
}

struct Sheet* find_sheet(const char* name) {
    for (int i = 0; i < MAX_SHEETS; i++) {
        if (sheets[i].in_use && strcasecmp(sheets[i].name, name) == 0) {
            return &sheets[i];
        }
    }
    return NULL;
}

int parse_cell_ref(const char* ref, struct Sheet** s, int* r, int* c) {
    char buf[16];
    strncpy(buf, ref, sizeof(buf)-1);
    buf[15] = 0;
    char *bang = strchr(buf, '!');
    if (!bang) return 0;
    *bang = 0;
    char *sheet_name = buf;
    char *cell_name = bang + 1;
    
    *s = find_sheet(sheet_name);
    if (!*s) return 0;
    
    if (strlen(cell_name) < 2) return 0;
    char col_c = tolower(cell_name[0]);
    if (col_c < 'a' || col_c > 'a' + MAX_COLS - 1) return 0;
    *c = col_c - 'a';
    
    char row_c = cell_name[1];
    if (row_c < '1' || row_c > '1' + MAX_ROWS - 1) return 0;
    *r = row_c - '1';
    
    return 1;
}

void do_new_sheet(const char* name) {
    int idx = -1;
    for (int i = 0; i < MAX_SHEETS; i++) {
        if (!sheets[i].in_use) {
            idx = i;
            break;
        }
    }
    if (idx == -1) {
        puts("Max sheets reached.");
        return;
    }
    strncpy(sheets[idx].name, name, 8);
    sheets[idx].name[8] = '\0';
    sheets[idx].in_use = 1;
    printf("Created sheet %s.\n", sheets[idx].name);
}

void do_fill(const char* ref, const char* data) {
    struct Sheet *s;
    int r, c;
    if (!parse_cell_ref(ref, &s, &r, &c)) {
        puts("Invalid reference.");
        return;
    }
    
    if (s->cells[r][c].data) {
        sheet_free(s, s->cells[r][c].data);
        s->cells[r][c].data = NULL;
    }
    
    memset(s->cells[r][c].raw_data, 0, 16);
    strncpy(s->cells[r][c].raw_data, data, 16);
    
    if (data[0] == '=') {
        struct Sheet *refs;
        int refr, refc;
        if (parse_cell_ref(data + 1, &refs, &refr, &refc)) {
            s->cells[r][c].data = refs->cells[refr][refc].data;
            puts("Reference filled.");
            return;
        } else {
            puts("Invalid reference format in data.");
        }
    }
    
    s->cells[r][c].data = sheet_malloc(s, 8);
    memcpy(s->cells[r][c].data, data, strnlen(data, 8));
    puts("Cell filled.");
}

void do_erase(const char* ref) {
    struct Sheet *s;
    int r, c;
    if (!parse_cell_ref(ref, &s, &r, &c)) {
        puts("Invalid reference.");
        return;
    }
    if (s->cells[r][c].data) {
        if(s->cells[r][c].raw_data[0] != '=') {
            sheet_free(s, s->cells[r][c].data);
        }
        s->cells[r][c].data = NULL;
        memset(s->cells[r][c].raw_data, 0, 16);
        puts("Cell erased.");
    }
}

void do_merge(const char* ref, int w, int h, char separator) {
    struct Sheet *s;
    int r, c;
    if (!parse_cell_ref(ref, &s, &r, &c)) {
        puts("Invalid reference.");
        return;
    }
    
    if (c + w > MAX_COLS || r + h > MAX_ROWS) {
        puts("Merge area out of bounds.");
        return;
    }
    
    int count = 0;
    int total_bytes = 0;
    
    for (int i = r; i < r + h; i++) {
        for (int j = c; j < c + w; j++) {
            if (s->cells[i][j].data && s->cells[i][j].raw_data[0] != '=') {
                count++;
                total_bytes += 8;
            }
        }
    }
    
    if (count == 0) {
        puts("Nothing to merge.");
        return;
    }
    
    char *new_ptr = sheet_malloc(s, total_bytes);
    char *curr = new_ptr;
    
    int first = 1;
    for (int j = c; j < c + w; j++) {
        for (int i = r; i < r + h; i++) {
            if (s->cells[i][j].data) {
                if (!first) {
                    *curr = separator;
                    curr++;
                }
                first = 0;
                strncat(curr, s->cells[i][j].data, 8);
                curr += strlen(s->cells[i][j].data);

                if(s->cells[i][j].raw_data[0] != '=') sheet_free(s, s->cells[i][j].data);
                if(i!=r || j!=c) {
                    s->cells[i][j].data = NULL;
                    memset(s->cells[i][j].raw_data, 0, 16);
                }
            }
        }
    }
    
    s->cells[r][c].data = new_ptr;
    strcpy(s->cells[r][c].raw_data, "merged");
    puts("Cells merged.");
}

void do_print(const char* name) {
    struct Sheet* s = find_sheet(name);
    if (!s) { puts("Sheet not found."); return; }
    
    for (int i = 0; i < MAX_ROWS; i++) {
        for (int j = 0; j < MAX_COLS; j++) {
            if (s->cells[i][j].data) {
                printf("%c%d: %s\n", 'A'+j, i+1, s->cells[i][j].data);
            }
        }
    }
}

void do_print_raw(const char* name) {
    struct Sheet* s = find_sheet(name);
    if (!s) { puts("Sheet not found."); return; }
    
    for (int i = 0; i < MAX_ROWS; i++) {
        for (int j = 0; j < MAX_COLS; j++) {
             if (s->cells[i][j].raw_data[0] != 0) {
                 printf("%c%d: ", 'A'+j, i+1);
                 for(int k=0; k<16; k++) {
                     char ch = s->cells[i][j].raw_data[k];
                     if (ch) printf("%c", ch);
                 }
                 puts("");
             }
        }
    }   
}

void do_debug() {
    printf("sheets: %p\n", (void*)sheets);
}

int main() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    
    char line[256];
    while (1) {
        puts("Available commands:");
        puts("  fill <sheet>!<col><row> <data>");
        puts("  erase <sheet>!<col><row>");
        puts("  merge <sheet>!<col><row> <width> <height>");
        puts("  print <sheet>");
        puts("  print_raw <sheet>");
        puts("  new_sheet <sheet>");
        puts("  debug");
        puts("  exit");

        printf("> ");
        if (!fgets(line, sizeof(line), stdin)) break;
        
        char cmd[32] = {0};
        char arg1[32] = {0};
        char arg2[32] = {0};
        char arg3[32] = {0};
        char arg4 = ' ';

        int n = sscanf(line, "%31s %31s %31s %31s %c", cmd, arg1, arg2, arg3, &arg4);
        if (n <= 0) continue;
        
        if (strcmp(cmd, "fill") == 0 && n >= 3) {
            do_fill(arg1, arg2);
        } else if (strcmp(cmd, "erase") == 0 && n >= 2) {
            do_erase(arg1);
        } else if (strcmp(cmd, "merge") == 0 && n >= 4) {
            do_merge(arg1, atoi(arg2), atoi(arg3), arg4);
        } else if (strcmp(cmd, "print") == 0 && n >= 2) {
            do_print(arg1);
        } else if (strcmp(cmd, "print_raw") == 0 && n >= 2) {
            do_print_raw(arg1);
        } else if (strcmp(cmd, "new_sheet") == 0 && n >= 2) {
            do_new_sheet(arg1);
        } else if (strcmp(cmd, "debug") == 0) {
            do_debug();
        } else if (strcmp(cmd, "exit") == 0) {
            exit(0);
        } else {
            puts("Unknown command. Supported: fill, erase, merge, print, print_raw, new_sheet, exit");
        }
    }
    return 0;
}
