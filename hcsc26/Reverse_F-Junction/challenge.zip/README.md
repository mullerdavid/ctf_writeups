# F-Junction Challenge

This challenge can be run locally using Docker/Podman.

## Running with Docker/Podman

```bash
# Build the container
docker build -t f-junction .

# Run the challenge
docker run --rm -it f-junction
```

## Running directly (requires Linux with libstdc++)

Because of different `libc` versions in various distros, it's recommended to use the Docker/Podman method above. Do this if you know what you're doing.

```bash
chmod +x junction
./junction
```

Make sure `libjunction.so` is in the same directory or your LD_LIBRARY_PATH.

## Notes

See `NOTE.md` for hints about the challenge.
