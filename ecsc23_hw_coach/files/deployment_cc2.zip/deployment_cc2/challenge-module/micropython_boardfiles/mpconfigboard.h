// Board and hardware specific configuration
#define MICROPY_HW_BOARD_NAME                   "PowerSlot RP2"
#define MICROPY_HW_FLASH_STORAGE_BYTES          (1408 * 1024)
