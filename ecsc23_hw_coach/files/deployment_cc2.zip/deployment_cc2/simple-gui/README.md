# BitBuster simple GUI

https://bitbuster.eu/simple-gui

Install requirements.txt, run ./main.py. Happy hacking!
