from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.board_config import BoardConfig
    from ..models.board_info import BoardInfo
    from ..models.slot_info import SlotInfo


T = TypeVar("T", bound="GetInfosResponse200")


@attr.s(auto_attribs=True)
class GetInfosResponse200:
    """
    Attributes:
        slot (Union[Unset, SlotInfo]):
        board_info (Union[Unset, BoardInfo]):
        board_config (Union[Unset, BoardConfig]):
    """

    slot: Union[Unset, "SlotInfo"] = UNSET
    board_info: Union[Unset, "BoardInfo"] = UNSET
    board_config: Union[Unset, "BoardConfig"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        slot: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.slot, Unset):
            slot = self.slot.to_dict()

        board_info: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.board_info, Unset):
            board_info = self.board_info.to_dict()

        board_config: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.board_config, Unset):
            board_config = self.board_config.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if slot is not UNSET:
            field_dict["slot"] = slot
        if board_info is not UNSET:
            field_dict["boardInfo"] = board_info
        if board_config is not UNSET:
            field_dict["boardConfig"] = board_config

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.board_config import BoardConfig
        from ..models.board_info import BoardInfo
        from ..models.slot_info import SlotInfo

        d = src_dict.copy()
        _slot = d.pop("slot", UNSET)
        slot: Union[Unset, SlotInfo]
        if isinstance(_slot, Unset):
            slot = UNSET
        else:
            slot = SlotInfo.from_dict(_slot)

        _board_info = d.pop("boardInfo", UNSET)
        board_info: Union[Unset, BoardInfo]
        if isinstance(_board_info, Unset):
            board_info = UNSET
        else:
            board_info = BoardInfo.from_dict(_board_info)

        _board_config = d.pop("boardConfig", UNSET)
        board_config: Union[Unset, BoardConfig]
        if isinstance(_board_config, Unset):
            board_config = UNSET
        else:
            board_config = BoardConfig.from_dict(_board_config)

        get_infos_response_200 = cls(
            slot=slot,
            board_info=board_info,
            board_config=board_config,
        )

        get_infos_response_200.additional_properties = d
        return get_infos_response_200

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
