from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..models.analog_channel_info_type import AnalogChannelInfoType
from ..models.channel_source import ChannelSource
from ..types import UNSET, Unset

T = TypeVar("T", bound="AnalogChannelInfo")


@attr.s(auto_attribs=True)
class AnalogChannelInfo:
    """
    Attributes:
        type (Union[Unset, AnalogChannelInfoType]):
        id (Union[Unset, int]):
        sources (Union[Unset, List[ChannelSource]]):
        amplifier_gains (Union[Unset, List[int]]): possible V/V gains of the variable amplifier
    """

    type: Union[Unset, AnalogChannelInfoType] = UNSET
    id: Union[Unset, int] = UNSET
    sources: Union[Unset, List[ChannelSource]] = UNSET
    amplifier_gains: Union[Unset, List[int]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = self.type.value

        id = self.id
        sources: Union[Unset, List[str]] = UNSET
        if not isinstance(self.sources, Unset):
            sources = []
            for sources_item_data in self.sources:
                sources_item = sources_item_data.value

                sources.append(sources_item)

        amplifier_gains: Union[Unset, List[int]] = UNSET
        if not isinstance(self.amplifier_gains, Unset):
            amplifier_gains = self.amplifier_gains

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type is not UNSET:
            field_dict["type"] = type
        if id is not UNSET:
            field_dict["id"] = id
        if sources is not UNSET:
            field_dict["sources"] = sources
        if amplifier_gains is not UNSET:
            field_dict["amplifierGains"] = amplifier_gains

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _type = d.pop("type", UNSET)
        type: Union[Unset, AnalogChannelInfoType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = AnalogChannelInfoType(_type)

        id = d.pop("id", UNSET)

        sources = []
        _sources = d.pop("sources", UNSET)
        for sources_item_data in _sources or []:
            sources_item = ChannelSource(sources_item_data)

            sources.append(sources_item)

        amplifier_gains = cast(List[int], d.pop("amplifierGains", UNSET))

        analog_channel_info = cls(
            type=type,
            id=id,
            sources=sources,
            amplifier_gains=amplifier_gains,
        )

        analog_channel_info.additional_properties = d
        return analog_channel_info

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
