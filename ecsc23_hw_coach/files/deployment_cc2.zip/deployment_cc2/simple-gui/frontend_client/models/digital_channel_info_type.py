from enum import Enum


class DigitalChannelInfoType(str, Enum):
    DIGITAL = "digital"

    def __str__(self) -> str:
        return str(self.value)
