
from frontend_client import AuthenticatedClient
import frontend_client.api as api
import frontend_client.models as models
import frontend_client.types as types

import frontend_client.api.get_infos as api_get_infos
import frontend_client.api.set_channel_config as api_set_channel_config
import frontend_client.api.set_board_config as api_set_board_config
import frontend_client.api.dump as dump

from typing import Optional, Any, Tuple, Dict, Callable, List
from dataclasses import dataclass
from mdns_resolve import resolve, lazy, static_lazy

import json
import time
import base64
import numpy as np
import math
import requests

@dataclass
class ChannelMetadata:
    channel_id: int
    channel_type: str
    byte_offset: int
    bit_offset: int
    bit_length: int

    bias: int
    parse_offset: float
    gain: float
    parse_scaler: float


@dataclass
class Metadata:
    samples: int
    bytes_per_sample: int
    sample_rate: int
    stride: int
    offset: int
    trigger_offset: int
    full_size: int
    channels: List[ChannelMetadata]

def parse_data(schema: models.DataSchema, data: bytes):
    parsed_data = []
    channels = []
    used_bits = 0
    for c in schema.channels:
        if c.bits + (used_bits % 8) > 8:
            # when we would fill up more than the remaining byte, then we hope that the rest of the byte was
            # actually padding and the data starts in the next byte...
            # in theory this is not properly specified...
            used_bits += 8 - (used_bits % 8)

        if c.bits == 0:
            print("# warning, there are channels which have been enabled but surpass the capability for capturing")
            print("# currently only 16 bits per sample are supported, each analog channel uses 8 bits, each digital 1 bit")
            print("# analog channels are always preferred to digital channels, do if you have both analog channels enabled, you will not be able to see the digital ones")

        elif c.bits == 1:
            channels.append(ChannelMetadata(
                c.channel_id, c.channel_type, math.floor(used_bits/8.0), used_bits % 8, c.bits,
                c.bias, 0,
                c.gain, 1,
            ))

        elif c.bits == 8:
            channels.append(ChannelMetadata(
                c.channel_id, c.channel_type, math.floor(used_bits/8.0), used_bits % 8, c.bits,
                c.bias, 0,
                c.gain, 1,
            ))

        else:
            raise ValueError("schema has channel with weird amount of bits (not 1 or 8)", c)

        used_bits += c.bits

    metadata = Metadata(
        schema.samples,
        2,  # math.ceil(used_bits/8.0),
        schema.sample_rate,
        schema.stride,
        schema.offset,
        schema.trigger_offset,
        schema.fullsize,
        channels,
    )

    # Sanity check
    if len(data) != schema.samples*metadata.bytes_per_sample:
        raise ValueError(f"dump is not the correct size, expected {schema.samples} samples of {math.ceil(used_bits/8.0)} = {schema.samples*math.ceil(used_bits/8.0)}, got {len(data)}")
    
    for i in range(metadata.samples):
        # Parse data.
        sample_data = {}
        for c_i, channel in enumerate(metadata.channels):
            if channel.channel_type == models.ChannelType.ANALOG:
                # Analog channel parsing.
                sample_data[f"ana{channel.channel_id}"] = data[i * metadata.bytes_per_sample + channel.byte_offset]
            elif channel.channel_type == models.ChannelType.DIGITAL:
                # Digital channel parsing.
                val = data[i * metadata.bytes_per_sample + channel.byte_offset]
                sample_data[f"dig{channel.channel_id}"] = int((val & (1 << channel.bit_offset)) != 0)
            else:
                raise ValueError("Invalid channel type. Cannot parse data.")
            
        parsed_data.append(sample_data)

    return parsed_data

class BitBusterChannel:
    channel_id: int             # Integer internal channel id
    channel_name: str           # Channel liternal name
    sources: list               # List of sources

    selected_source: str        # Selected source
    enabled: bool               # Selection if channel should be enabled.

    dirty: bool                 # Modified/dirty bit for optimizing update to device.

    def __init__(self, channel_id: int, sources: list, channel_name: str = ""):
        self.channel_id = channel_id
        self.sources = sources

        self.selected_source = self.sources[0]
        self.enabled = False
        self.dirty = False

        if channel_name == "":
            channel_name = f"Channel {channel_id}"
        self.channel_name = channel_name

    def get_uid(self) -> str:
        if isinstance(self, BitBusterAnalogChannel):
            return f"ana{self.channel_id}"
        elif isinstance(self, BitBusterDigitalChannel):
            return f"dig{self.channel_id}"
        else:
            return f"ch{self.channel_id}"
        
    def set_enabled(self, enabled: bool):
        if self.enabled != enabled:
            self.dirty = True
            self.enabled = enabled

    def set_selected_source(self, source: str):
        if self.selected_source != source:
            self.dirty = True
            self.selected_source = source

class BitBusterAnalogChannel(BitBusterChannel):
    amplifier_gains: list               # List of valid amplifier gains

    selected_amplifier_gain_idx: int    # Selected amplifier gain (index into self.amplifier_gains)
    selected_offset: int                # DAC offset
    
    def __init__(self, channel_id: int, sources: list, amplifier_gains: list):
        super().__init__(channel_id, sources)
        self.amplifier_gains = amplifier_gains
        self.selected_amplifier_gain_idx = 0
        self.selected_offset = 0

    def set_selected_amp_gain(self, new_idx: int):
        if self.selected_amplifier_gain_idx != new_idx:
            self.dirty = True
            self.selected_amplifier_gain_idx = new_idx

    def set_selected_offset(self, offset: int):
        if self.selected_offset != offset:
            self.dirty = True
            self.selected_offset = offset

    def get_voltage_range(self) -> tuple:
        # DAC_value = 2000 - 400*v_center
        center_voltage = (2000 - self.selected_offset) / 400
        # v_adc = v_in * 1/4 * amp
        v_in_delta = 1.0 * 4 / self.amplifier_gains[self.selected_amplifier_gain_idx]
        return (center_voltage-v_in_delta, center_voltage+v_in_delta)
    
    def set_voltage_range(self, range: tuple) -> bool:
        # Checks if given voltage range is satisfiable. Returns true if possible
        # and success, False if the requested range is not valid.
        if range[0] > range[1]:
            return False
        v_center = (range[0] + range[1]) / 2
        v_delta = max(range[0], range[1]) - v_center
        amp_ideal = 1.0 / (v_delta * 0.25)
        
        amp_gains = np.asarray(self.amplifier_gains)
        amp_closest_i = (np.abs(amp_gains - amp_ideal)).argmin()

        amp_error = np.abs(amp_gains[amp_closest_i] / amp_ideal - 1)
        if amp_error >= 1:
            return False
        
        # Calculate required offset.
        req_offset = int(np.round(2000 - 400 * v_center))
        if req_offset < 0 or req_offset > 4096:
            return False
        
        # Found a valid configuration.
        self.set_selected_amp_gain(amp_closest_i)
        self.set_selected_offset(req_offset)
        return True

class BitBusterDigitalChannel(BitBusterChannel):
    def __init__(self, channel_id: int, sources: list):
        super().__init__(channel_id, sources)

BLK_MAXSTRIDE = 1024

class BitBusterDatacache:

    data_blocks: dict
    data_schema: str
    client: AuthenticatedClient
    is_fully_mapped: bool

    def __init__(self, client: AuthenticatedClient):
        self.client = client
        self.data_schema = ""
        self.data_blocks = {}
        self.is_fully_mapped = False

    def __getitem__(self, index: int):
        # Check bounds
        if index >= (16*1024*1024) or index < 0:
            return {}
        
        # Get the corresponding block index.
        blkindex, subindex = divmod(index, 4096)

        # Check if block cache hit.
        if blkindex in self.data_blocks:
            # Block hit
            
            # Check for data hit.
            if subindex in self.data_blocks[blkindex]:
                return self.data_blocks[blkindex][subindex]
            
            # Data miss
            self.loadblock(index)

            #assert(subindex in self.data_blocks[blkindex])
            if subindex not in self.data_blocks[blkindex]:
                print(f"ASSERT FAILED: idx={index} blk={blkindex} subidx={subindex}")
                assert(0)
            return self.data_blocks[blkindex][subindex]
        
        else:
            # Block miss, initial load of block.
            self.loadblock(index)

            assert(subindex in self.data_blocks[blkindex])
            return self.data_blocks[blkindex][subindex]
    
    def invalidate(self):
        self.data_blocks = {}
        self.is_fully_mapped = False

    def load_from_bitbuster(self, offset: int, stride: int, amount: int):
        dump_resp = None

        for i in range(10):
            stride_val = int(np.log2(stride)+1)
            print(f"DUMP stride={stride_val} offset={offset} amount={amount}")
            resp = dump.sync_detailed(client=self.client, stride=stride_val, offset=offset, amount=amount)
            if resp.status_code == 503:
                print("retrying dump")
                continue
            elif resp.status_code == 200:
                dump_resp = resp
                break
            else:
                raise ValueError("unexpected status code", resp.status_code)

        if dump_resp is None or dump_resp.parsed.payload is None:
            raise ValueError("could not read dump")
        
        data_schema_enc = dump_resp.headers.get("X-Data-Schema")
        if not data_schema_enc:
            raise ValueError("could not read data schema")
        schema = models.DataSchema.from_dict(json.loads(base64.b64decode(data_schema_enc))["payload"])
        
        # Check for data schema integrity
        if self.data_schema != "":
            # Data schema changed, invalidate cache.
            print("INVALIDATING CACHE")
            self.invalidate()

        parsed_data = parse_data(schema, dump_resp.parsed.payload.read())
        #print(parsed_data)

        for i in range(amount):
            # addr = addr + (1 << stride)
            # addr_s = addr_s + (1 << (stride_s + 1))
            idx = offset + i * stride
            ld_blk, ld_subidx = divmod(idx, 4096)
            if not ld_blk in self.data_blocks:
                self.data_blocks[ld_blk] = {}
            if ld_subidx in self.data_blocks[ld_blk]:
                if self.data_blocks[ld_blk][ld_subidx] != parsed_data[i]:
                    print(f"CACHE WRITE MISMATCH FOUND FROM DUMP! blk={ld_blk} subidx={ld_subidx} i={i}")
                    print(self.data_blocks[ld_blk][ld_subidx])
                    print(parsed_data[i])
            self.data_blocks[ld_blk][ld_subidx] = parsed_data[i]

    def cache_warmup(self):
        # Cache warmup
        warmup_stride = 16
        print(f"Cache warmup in progress... Please be patient.")
        self.load_from_bitbuster(0, warmup_stride, (16 * 1024 * 1024) // warmup_stride)

    def loadblock(self, index: int):
        blkindex, subindex = divmod(index, 4096)

        # Get max stride possible. Calculate by getting largest modulo-class for subindex, up to BLK_MAXSTRIDE.
        stride = BLK_MAXSTRIDE
        while subindex % stride != 0:
            stride /= 2
            if stride == 1:
                break

        # We have the stride and blockindex, load it into our memory.
        amount = math.ceil((4096//stride) / 2048) * 2048

        self.load_from_bitbuster(blkindex*4096, stride, amount)


class BitBusterConnector:

    _debug: bool                    # Debug mode switch

    bb_ipaddr: str                  # Resolved ipaddress of the bitbuster device this connects to.
    bb_pass: str                    # BitBuster API password
    client: AuthenticatedClient     # Authed BitBuster client handle

    channels: list                  # Available channels on the connected BitBuster device

    board_name: str                 # Name of the board connected
    sampling_rates: list            # Available sampling rates
    selected_sampling_rate_idx: int # Index into sampling_rates that selects the current sampling rate used.

    trigger_offset: int             # Trigger offset
    trigger_channel_uid: str        # UID of the trigger channel
    trigger_threshold: int          # Trigger analog threshold
    trigger_mode: models.TriggerConfigurationTrigger # Trigger mode
    trigger_enabled: bool           # Trigger is enabled or not

    datacache: BitBusterDatacache   # Datacache


    def __init__(self, bb_ipaddr: str, bb_pass: str):
        self.bb_ipaddr = bb_ipaddr
        self.bb_pass = bb_pass
        self.client = None
        self.channels = []
        self.board_name = "-"
        self.sampling_rates = []
        self.selected_sampling_rate_idx = 0
        self.datacache = None

        self.trigger_offset = 0
        self.trigger_channel_uid = "ana0"
        self.trigger_threshold = 127
        self.trigger_mode = models.TriggerConfigurationTrigger.BOTH
        self.trigger_enabled = False

        self._debug = True

    def _log(self, s: str):
        if self._debug:
            print(s)

    def sampling_done(self) -> bool:
        if self.client is None:
            return False
        
        resp = dump.sync_detailed(client=self.client, stride=1, offset=0, amount=2048)

        if resp.status_code == 200:
            # Sampling done.
            return True
        elif resp.status_code == 503:
            # Sampling in progress. For now we also treat this as false.
            return False
        else:
            return False

    def get_sample_data(self, channel_uid: str, index: int) -> int:
        if self.client is None:
            self._log("Tried to access data before initializing the client.")
            return 0
        
        sample_data = self.datacache[index]

        if channel_uid in sample_data:
            return sample_data[channel_uid]
        else:
            self._log(f"Accessed invalid channel {channel_uid} at sample index {index}. Returning 0, but data is invalid.")
            return 0
    
    # Connect to the BitBuster.
    def connect(self) -> bool:
        for a in [static_lazy(self.bb_ipaddr), lazy(resolve, self.bb_ipaddr)]:
            if a() is None:
                continue

            self.client = AuthenticatedClient(base_url=f"http://{a()}", auth_header_name="X-Password", prefix=None,
                                         token=self.bb_pass, raise_on_unexpected_status=False, verify_ssl=False,
                                         follow_redirects=False, timeout=60*5)

            answer = api.get_infos.sync_detailed(client=self.client.with_timeout(1))
            if answer.status_code == 200:
                self.bb_ipaddr = a()

                self._log(f"Connected to BitBuster {self.bb_ipaddr}.")
                self.datacache = BitBusterDatacache(self.client)
                self.update_info()
                return True

        self._log(f"Connection error: Recieved HTTP status code {answer.status_code}.")
        self.client = None
        return False

        
    def get_channel_info(self):
        r = requests.get(f"http://{self.bb_ipaddr}/channel", headers={"X-Password": self.bb_pass})

        if r.status_code != 200:
            return []
        
        return r.json()
    
    def get_slot_info(self):
        r = requests.get(f"http://{self.bb_ipaddr}/slot", headers={"X-Password": self.bb_pass})

        if r.status_code != 200:
            return []
        
        return r.json()
    
    def get_current_config_info(self):
        r = requests.get(f"http://{self.bb_ipaddr}/config", headers={"X-Password": self.bb_pass})

        if r.status_code != 200:
            return []
        
        return r.json()
        
    # Update the current object tree from the BitBuster get info API endpoint.
    def update_info(self) -> bool:
        if self.client == None:
            return False
        
        answer = api.get_infos.sync_detailed(client=self.client)
        if answer.status_code != 200:
            return False
        
        info_payload = answer.parsed.additional_properties["payload"]
        channels = info_payload["channels"]
        self.sampling_rates = info_payload["samplingRates"]

        channel_info = self.get_channel_info()
        slot_info = self.get_slot_info()
        if "payload" in slot_info and slot_info["payload"] is not None:
            slot_info = slot_info["payload"]["channels"]
        else:
            slot_info = []
        config_info = self.get_current_config_info()["payload"]

        self.selected_sampling_rate_idx = self.sampling_rates.index(config_info["samplingRate"])

        # Sampling settings
        if config_info["trigger"] is not None:
            # Setup trigger
            self.trigger_enabled = True
            self.trigger_offset = config_info["trigger"]["triggerDelay"]
            self.trigger_channel_uid = f'{config_info["trigger"]["channelType"][:3]}{config_info["trigger"]["channelID"]}'
            trigger_mode_str = config_info["trigger"]["trigger"]
            if trigger_mode_str == "rising":
                self.trigger_mode = models.TriggerConfigurationTrigger.RISING
            elif trigger_mode_str == "falling":
                self.trigger_mode = models.TriggerConfigurationTrigger.FALLING
            elif trigger_mode_str == "both":
                self.trigger_mode = models.TriggerConfigurationTrigger.BOTH
            else:
                raise ValueError("Got invalid trigger mode from BitBuster API.")
        else:
            self.trigger_enabled = False

        self.channels = []
        for c in channels:
            if c["type"] == "analog":
                ch = BitBusterAnalogChannel(c["id"], c["sources"], c["amplifierGains"])
                cinfo_arr = [s for s in channel_info if s["id"] == c["id"] and s["type"] == c["type"]]
                cslot_arr = [s for s in slot_info if s["id"] == c["id"] and s["type"] == c["type"]]
                if len(cinfo_arr) > 0:
                    ch.enabled = cinfo_arr[0]["enabled"]
                    ch.selected_offset = cinfo_arr[0]["dcOffset"]
                    ch.selected_source = cinfo_arr[0]["source"]
                    sel_amp_gain = cinfo_arr[0]["amplifierGain"]
                    ch.selected_amplifier_gain_idx = c["amplifierGains"].index(sel_amp_gain)
                if len(cslot_arr) > 0:
                    ch.channel_name = cslot_arr[0]["name"]
                self.channels.append(ch)
            elif c["type"] == "digital":
                ch = BitBusterDigitalChannel(c["id"], c["sources"])
                cinfo_arr = [s for s in channel_info if s["id"] == c["id"] and s["type"] == c["type"]]
                cslot_arr = [s for s in slot_info if s["id"] == c["id"] and s["type"] == c["type"]]
                if len(cinfo_arr) > 0:
                    ch.enabled = cinfo_arr[0]["enabled"]
                if len(cslot_arr) > 0:
                    ch.channel_name = cslot_arr[0]["name"]
                self.channels.append(ch)
            else:
                return False
            
        return True
    
    # Update channel configuration on the BitBuster from the current object tree.    
    def commit_channel_config(self):
        self._log("Commiting channel configurations...")
        for c in self.channels:
            if not c.dirty:
                continue
            
            if isinstance(c, BitBusterAnalogChannel):
                self._log(f"Setting analog channel config for {c.get_uid()}. source={c.selected_source}, enabled={c.enabled}, gain={c.amplifier_gains[c.selected_amplifier_gain_idx]}, offset={c.selected_offset}")
                self.set_channel_config(c.channel_id, "analog", c.selected_source, c.enabled, c.amplifier_gains[c.selected_amplifier_gain_idx], c.selected_offset, auto_retry=True)
                c.dirty = False
            elif isinstance(c, BitBusterDigitalChannel):
                self._log(f"Setting digital channel config für {c.get_uid()}. source={c.selected_source}, enabled={c.enabled}")
                self.set_channel_config(c.channel_id, "digital", c.selected_source, c.enabled, auto_retry=True)
                c.dirty = False
    
    # Commit the board configuration and simultaneaously start the sample acquisition
    def sample(self):
        if self.datacache:
            self.datacache.invalidate()
        print(f"[SAMPLING] srate={self.sampling_rates[self.selected_sampling_rate_idx]} offset={self.trigger_offset} trig_en={self.trigger_enabled}")

        trig_channel_type = None
        trig_channel_id = 0
        if self.trigger_channel_uid.startswith("dig"):
            trig_channel_type = models.ChannelType.DIGITAL
            trig_channel_id = int(self.trigger_channel_uid[len("dig"):])
        elif self.trigger_channel_uid.startswith("ana"):
            trig_channel_type = models.ChannelType.ANALOG
            trig_channel_id = int(self.trigger_channel_uid[len("ana"):])
        else:
            raise ValueError(f"Invalid channel UID: {self.trigger_channel_uid}")
        
        self.set_board_config(self.sampling_rates[self.selected_sampling_rate_idx],
                              models.TriggerConfiguration(trig_channel_type, trig_channel_id, self.trigger_mode, self.trigger_offset) if self.trigger_enabled else None, # -0x802000//2
                              "single",
                              auto_retry=True)

    # Set a channel configuration.
    def set_channel_config(self, channel_id: int, type: str, source: str, enabled: bool,
                           amplifier_gain: int = None, bias: int = None, auto_retry: bool = True):
        if source == models.ChannelSource.INT.value:
            source = models.ChannelSource.INT
        elif source == models.ChannelSource.EXT.value:
            source = models.ChannelSource.EXT
        else:
            raise ValueError("Invalid source type", source)

        if type == models.ChannelType.ANALOG:
            config = models.analog_channel_configuration.AnalogChannelConfiguration(
                models.analog_channel_configuration.AnalogChannelConfigurationType.ANALOG,
                channel_id,
                source,
                enabled,
                amplifier_gain,
                bias,
            )
        elif type == models.ChannelType.DIGITAL:
            config = models.digital_channel_configuration.DigitalChannelConfiguration(
                models.digital_channel_configuration.DigitalChannelConfigurationType.DIGITAL,
                channel_id,
                source,
                enabled,
            )
        else:
            raise ValueError("Invalid channel type", type)

        answer = api.set_channel_config.sync_detailed(client=self.client, json_body=config)
        if answer.status_code != 200:
            content = json.loads(answer.content)

            # Auto-retry on busy
            if "error" in content and "busy" in content["error"].lower() and auto_retry:
                time.sleep(1)
                return self.set_channel_config(channel_id, type, source, enabled, amplifier_gain, bias, auto_retry=False)
            
            raise Exception("error setting channel config", answer, answer.parsed["error"])

        if answer is None or not answer.parsed.success:
            raise Exception("error setting channel config", answer)
        
    # Set board config and start a sample.
    def set_board_config(self, sampling_rate: int, trigger: Optional[Any], sampling: str, auto_retry: bool = True):
        if trigger is None:
            trigger = types.Unset()

        if sampling == models.BoardConfigSampling.STOP.value:
            sampling = models.BoardConfigSampling.STOP
        elif sampling == models.BoardConfigSampling.SINGLE.value:
            sampling = models.BoardConfigSampling.SINGLE
        elif sampling == models.BoardConfigSampling.CONTINUOUS.value:
            sampling = models.BoardConfigSampling.CONTINUOUS
        else:
            raise ValueError("invalid sampling method", sampling)

        config = models.board_config.BoardConfig(
            sampling_rate,
            sampling,
            trigger,
        )
        answer = api.set_board_config.sync_detailed(client=self.client, json_body=config)
        if answer.status_code != 200:
            content = json.loads(answer.content)
            
            # Auto-retry on busy
            if "error" in content and "busy" in content["error"].lower() and auto_retry:
                time.sleep(1)
                return self.set_board_config(sampling_rate, trigger, sampling)
            
            raise Exception("error setting channel config", answer)

        if answer is None or not answer.parsed.success:
            raise Exception("error setting channel config", answer)
        
    


