from dpkt.dns import DNS, DNS_A
import socket
import struct


def resolve(x):
    print("# resolving", x, "via custom dns query, this might take a while")
    print("# it is best to take this result and hardcode it as address if you don't change the board's ip often")
    UDP_IP = "0.0.0.0"
    UDP_PORT = 5353
    MCAST_GRP = '224.0.0.251'

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((UDP_IP,UDP_PORT))

        # join the multicast group
        mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        sock.settimeout(20)

        sock.sendto(DNS(qd=[DNS.Q(name=x)]).pack(), (MCAST_GRP,UDP_PORT))

        while True:
            try:
                data, host = sock.recvfrom(1024)
                dns = DNS(data)

                if len(dns.an) > 0:
                    for an in dns.an:
                        if an.name == x and (an.type == DNS_A):
                            res = socket.inet_ntoa(an.rdata)
                            print("resolved", x, "to", res)
                            return res
            except socket.timeout:
                print("timeouted while resolving...")
                break

        return None
    finally:
        sock.close()

def lazy(func, *args, **kwargs):
    result = None
    resolved = False

    def wrapper():
        nonlocal resolved
        nonlocal result
        if not resolved:
            result = func(*args, **kwargs)
            resolved = True
            print("lazy resolved", result)
        return result

    return wrapper


def static_lazy(v):
    return lazy(lambda: v)

