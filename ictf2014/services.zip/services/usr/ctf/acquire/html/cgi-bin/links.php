<html>
  <head>
    <title>Open Relay Server List (ORSL): Links</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="keywords" content="open relay lists, spam lists, spam, open relay server lists, ORSL">
    <link rel="stylesheet" href="/acquire/spam.css" type="text/css">
  </head>
  <body>
 <div class="banner">
      <h1>Links!</h1>
    </div>


    <div class="sidebar">
      <h2>Menu</h2>

      <ul>
        <li><a href="index.php">ORSL</a></li>

        <li><a href="howto.php">Howto</a></li>

        <li><a href="paid_service.php">Paid Service</a></li>

        <li><a href="contact.php">Contact</a></li>

        <li><a href="links.php">Links</a></li>
      </lu>
    </div>

    <div class="main">

		<p>
		Great websites that teach you how to become a spam expert! Generate <B>millions</B> 
		of emails with one click!

	<ul>

	  <li><a href="http://www.bullet8.com/">Spam Friendly Hosting</a></li>

	  <li><a href="http://www.marketing-3000.net/">Bulk Email
	  Software</a></li>

	  <li><a href="http://www.wfdirect.com/">WF Direct</a></li>

	  <li><a
	  href="http://www.marketingsplash.com/stealth.shtml.htm">Stealth
	  Mailer</a></l >

		<li><a href="http://www.agoogle.com/">Agoogle</a></li>

		<li><a href="http://www.filterblister.com/">Filter
		Blister</a></li>

		<li><a href="http://www.blackboxhosting.com/">More
		Hosting</a></li>

		<li><a href="http://www.cleanmymailbox.com/fb/">Filter
		Freeze</a></li>

		</ul>
 </div>
     <div class="footer">


Supported by the <a href="/~aqs/">Association for Quality SPAM</a>!
     </div>
  </body>
</html>
