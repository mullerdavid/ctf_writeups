<html>
<head>
<title>Open Relay Server List (ORSL): Links</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="open relay lists, spam lists, spam, open relay server lists, ORSL">
<meta name="description" content="List of Open erlay Server Lists.">
</head>
<body bgcolor="#CCCC99" text="#663300" link="navy" alink="navy" vlink="navy">
<table width="700" border="0" align="center" height="500" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0">
  <tr valign="top"> 
    <td> 
	<div align="center" >

      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="18%" bgcolor="#808000"> 
            <div align="center" ><b><a href="index.php" class="menu">ORSL</a></b></div>
          </td>
          <td width="18%" bgcolor="#808000"> 
            <div align="center" ><b><a href="howto.php" class="menu">Howto</a></b></div>
          </td>
          <td width="18%" bgcolor="#808000"> 
            <div align="center" class="menu"><b><a href="paid_service.php" class="menu">Paid Service</a></b></div>
          </td>
          <td width="18%" bgcolor="#808000"> 
            <div align="center"><b><a href="contact.php" class="menu">Contact</a></b></div>

          </td>
          <td width="18%" bgcolor="#808000"> 
            <div align="center"><b><a href="links.php" class="menu">Links</a></b></div>
          </td>
        </tr>
      </table>
	</div>
     <table width="100%" border="0">
        <tr> 
          <td width="5%">&nbsp;</td>
          <td width="90%">
		<BR>
		Great websites that teach you how to become a spam expert. Generate <B>millions</B> 
		of emails with one click!

		<UL>
		<LI><A href="http://www.filterbuster.com/">Filter Buster</A></LI>
		<LI><A href="http://www.blackboxhosting.com/">More Hosting</A></LI>
		<LI><A href="http://www.cleanmymailbox.com/fb/">Filter Freeze</A></LI>
		</UL>
		<BR>
          </td>
          <td width="5%">&nbsp;</td>
       </tr>

</table>

