<html>
  <head>
    <title>Open Relay Server List (ORSL): Contact</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="open relay lists, spam lists, spam, open relay server lists, ORSL" />
    <link rel="stylesheet" href="/acquire/spam.css" type="text/css" />
  </head>
  <body>

       <div class="banner">
      <h1>Contact Info</h1>
    </div>

    <div class="sidebar">
      <h2>Menu</h2>

      <ul>
        <li><a href="index.php">ORSL</a></li>

        <li><a href="howto.php">Howto</a></li>

        <li><a href="paid_service.php">Paid Service</a></li>

        <li><a href="contact.php">Contact</a></li>

        <li><a href="links.php">Links</a></li>
      </lu>
    </div>

    <div class="main">
<p><B>Name:</B> Mark Nerds 
		<B>Email:</B> (please do not SPAM us): admin@spam4nerds.com</p>

<pre>
-----BEGIN PGP PUBLIC KEY BLOCK-----

Version: GnuPG v1.2.4 (GNU/Linux)<BR>
mQGiBD+AkVURBACF+N3+HzIh0NFPzPFl47ZEvDKVaIO9m553HNnDy3M41Ca/MdGd
cHO8opYgYvNpArNZZxjN7fqNbkXTyBz4Dn1BhlheOjw1Z9c3z3Kc/MlsywTaJ3XU
9D9GY3NAT3rZ58yF/wLZCMZtrP6wcT2QNHfmqcADjs2cA2jEQSaOMyQmwwCg2Moe
HhmTfKM3oMyMWcurQOruzXcD/3kTZth6uxjRUqHu8cPlaTI9O/Pp6h2+uY909eGn
+QpV9m6ud69LL88KCsaPtiEtmYsNr2CsURWL9BlIBas0LpBlNKwlCzKyoFVmlsjG
VsSodCmI6Orgvc7oIlw5/iIYCiHiuHi3djtPnSz0PCvRMzJfExu/V30yCzlk53+K
wh6TA/94NdSlOOqptDJ1wh2N+CZtGIdofPf4X112Barh5GM6rxVnksRicNcUl2T0
ew/9QnWbqKv2zVZipE/Y2LI2yn1KYs9C7aSwNE8L1KIB7gA6n4VLgLc0v6HldGEp
WGRU+aPG31BFApkuTvist99UIOfvtqjQzQti96Hs0ranWgIIxrQxV2lsc29uIENo
ZW4gKGZvciBjczI3OSBvbmx5KSA8d2lsc29uQGNzLnVjc2IuZWR1PohZBBMRAgAZ
BQI/gJFVBAsHAwIDFQIDAxYCAQIeAQIXgAAKCRBk8gPLQUIjbcQ2AJ9cVNUeAuXU
ZNw2kKSnNVeB3tLwFwCggpo2kKumW/l7yaVPWeD5KboqQRG5AQ0EP4CRWBAEAKXS
45uzemXS8njh8Uq5UPzsbo/fBUQ9iX3rjpKnrfk5zWp6IkUMhuw9Mg8ByXQebMxL
9NoV/KN4uB8F6xoGWkT4VUG3XasAyt8UKIkyhGKlnHRepGOJ/WbBcR2cWMFbe0yc
lNWvkuTfB9vXlN5OvK1bgwZWaRuojo4jfJaCT2+DAAMGA/wMjHJiKzCRvyMAsnNF
LyYLjNn3jpswJSWwXCGmUJl0Ufd2GryKcQw51eYyA9nbi80C5s2I5geK/k/OFWE7
uS/5XXP+o0+Fu9xEyPsOUUzv4iWA47JYfyD9gY+b6H1nkR4Ca7WSTris7V7JSkvs
mJfs0aQADLi1/M6jT/CIfjCjw4hGBBgRAgAGBQI/gJFYAAoJEGTyA8tBQiNt9u0A
n2dvob71UvbgzdCANh/QpUTwHC4dAJ0W2XGBv2Wk/7lFPXQi/+j26kasYZkBogQ+
5ivzEQQAtCzHUmDMP1dcgWtrj2JeoJk7dcnZN+QhTPi2ospr2CfbXFTV+foneGJC
nkM0YoIO0Qk234FI8Nt812qVKSGYCCt0b12zFbMXataLUJGckX/+1WUjJRFZ5X5T
Wqsuzt7Y1WzQmxBJdBgBqeVMM2H03IseOJmGDXYB3L5G4KuRlxcAoM6bKgrjaqtP
gshRoSPUtUfmiMmvA/9IjTGMlNzOWA4TckbORrY3m4XNnhhMQke9UI0cMKjclk5a
+N57D9QPHJD3Xqo3db60qfxfXhQCHA1JWZsg2JZhVEmDtl9e8WQTaoAwLo563brr
rruJd6MKlSCxSIYLPBMDTQNG1UscIMBQkLBlria+XDV04IGVSnbKn0ckea3oeAP/
cCXF1zrpVDaRG1JqwxDFXjbxHRHSIeJ0HcsYtaXIIAIXNlsYhbtTTkmLC3Wiiwwe
JIj98X3SuwqvrHL78ejXSrEg1mIm0NLjH72A819yzCqQQbysQ8g9KXyY4Ay0nvXJ
+06dN2+5EyhcUQtBYcnU+<a href="howto_bak.php">x</a>Aq+3KsOr7DRd3AY2jdWEm0Ikdpb3Zhbm5pIFZpZ25h
IDx2aWduYUBjcy51Y3NiLmVkdT6IWQQTEQIAGQUCPuYr8wQLBwMCAxUCAwMWAgEC
HgECF4AACgkQq47uV3z6VWIztgCgw7GH7fzdNIPr9uddS2sac7/Q6dAAnRU0zHuC
N5giOs1t/L+tjhAhz0eouM0EPuYr9BADAJ/Mu5J1Uqda2hzXRs8FAvouIeEwZeQw
cc3AUufdStvHn+vqNawZ0iQXT+d+9Lxsb1DXM0ScBV50XLaI/Xrd3p62jJhdEsQ/
qmnchXbpHhSa+XKnXzFk8MI4fXn0bEtyZwADBQL/Sk1GE0lI0xa6o8PPh+J6Q6ul
Vcu3F6P94Ryxl4TtgxrvcdUW4JRcnkqDG6tgC4y4SSbNSNTXpockjfGXzg3QvViE
2Cg2rAnCI+G+XXIJMTINF0sIuxUU6FXcsMNoyFiriEYEGBECAAYFAj7mK/QACgkQ
q47uV3z6VWLd7QCfS09T4m7cFBMmTzcqwxVrMr0sJA4AoKjjhpH2M2YEBCTiyouK
P3hTjOXLmQGiBD2d58MRBACDIU7z/VCuB4N+Gy2OtXWMJngBlv4c/FuJAvdzyJD+
9x98x6yC4wT2KduZGcxmHdhNd/IN6YmMlqcAF0URwe6tk/VJloUAQ0m0tUWsEcIU
8KJSzpAA0AepyvowYuWkZzx5oNqgXMjuLwUrEhXvjQ9lOl9+dIpZ9NBH6f1accYy
JwCggPQjmUyhZnrf4rBgl0pXkQGEebMD/j/jBpFfdZhGC+UIphsleFFhWsBKQNzk
MIs97mzRDWP/zlFXkBtV/biP03Ad1FoBng1ginQS1mjgSVIj5lHeDnUilloebAuD
ndr+jlB6rc5KIFpN9XIXAIBwTxwp45yUslp282G8M7O/8QacSnVxLGaVkuJBlb0Z
Uoa19UcGU341A/9+wFLmQXUDInsVQ30T5mPjJUqAa2yJ32yue8mGodqWyiBzZSio
+EgkDNWPMJAmxinzmbYfU6PbJa/ol1tX5z0b1Fj+KEuDBg5QijJDD+f0X+l4jmxz
HTK9PvIMuGzGTTZhwIBFkTYTxvjnO4OPcsm3Bj7QrRwMHGZi6EJtGU6qU7Q2S2F2
aXRoYSBTcmluaXZhc2FuIChmb3IgdGVzdGJlZCkgPGthdml0aGFAY3MudWNzYi5l
ZHU+iF0EExECAB0FAj2d58MFCQPCZwAFCwcKAwQDFQMCAxYCAQIXgAAKCRDuF0Sg
6s9yWrHmAJ4r3ZoqUSp1dxP5/WQ3Tu6LkebzVgCfcJ+mOHr/mWCtVQrQKGUI4ans
rza5AQ0EPZ3nwxAEANCmQa+SbFOBh6J9eys3rApbaav31b42mGuVBMja007ihzr9
m8lAmR/0K2fPhTwDzYEQw7GzR1epuw1ozGT6DrOleXZMzlsJ/TL4u30C+BptOG3r
lT01NpvHZjEyEJtCERzGe6ekG4XUxTJgQIWZS5kyQTn5vrrr7+HjZ5+VFwenAAMF
BACDp7UzJFZoD88aNgg4WY+Uwkqqd8EpiCmjDKhDcxC3jWnr8QfMBNd4HzUvEchl
/zNbMOFmZNrJ8WWohOLWtOUFfscPBbeQ0rwn/5FXuj0nirxc2kGPi74iybFxsMaY
XwWidcpX+85L7RWfE16Q19dStAe7Ew5sG24d3dAj84MNzYhMBBgRAgAMBQI9nefD
BQkDwmcAAAoJEO4XRKDqz3JaBdcAn3H6WiwGFYTHBoxPQnn4pyw4uiSbAJ94eK+z
s1a5WVLRfwIeLVUqdUN5iA==
=fYfW

-----END PGP PUBLIC KEY BLOCK-----
</pre>

	  </div>
     <div class="footer">


Supported by the <a href="/~aqs/">Association for Quality SPAM</a>!
     </div>
  </body>
</html>
