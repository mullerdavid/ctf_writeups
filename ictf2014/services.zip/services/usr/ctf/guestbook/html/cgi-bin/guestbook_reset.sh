#!/bin/sh
cp guestbook.txt.orig guestbook.txt
chmod 666 guestbook.txt

