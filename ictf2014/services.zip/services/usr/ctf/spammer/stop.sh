#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/spammer//running.pid
