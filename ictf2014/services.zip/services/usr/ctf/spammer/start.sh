#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid spammer \
    --chdir /var/ctf/spammer/ \
    --make-pidfile \
    --pidfile /var/ctf/spammer//running.pid \
    --exec /usr/ctf/spammer//spammerd.py
