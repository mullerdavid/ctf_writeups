#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid aqs \
    --chdir /var/ctf/aqs/ \
    --make-pidfile \
    --pidfile /var/ctf/aqs//running.pid \
    --exec /usr/ctf/aqs//httpserver.py
