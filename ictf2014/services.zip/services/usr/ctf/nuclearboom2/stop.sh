#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/nuclearboom2//running.pid
