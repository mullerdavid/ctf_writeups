#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid nuclearboom2 \
    --chdir /var/ctf/nuclearboom2/ \
    --make-pidfile \
    --pidfile /var/ctf/nuclearboom2//running.pid \
    --exec /usr/ctf/nuclearboom2//nuclearboom2
