#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid temperature \
    --chdir /var/ctf/temperature/ \
    --make-pidfile \
    --pidfile /var/ctf/temperature//running.pid \
    --exec /usr/ctf/temperature//temperature
