cd /usr/ctf/powerplan
/sbin/start-stop-daemon -b --start --chdir /var/ctf/powerplan --name powerplan --exec /usr/bin/python /usr/ctf/powerplan/powerplan.pyc --
