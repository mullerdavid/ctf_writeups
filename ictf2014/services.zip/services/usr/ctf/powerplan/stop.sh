pkill -u powerplan
sleep 2
pkill -KILL -u powerplan
