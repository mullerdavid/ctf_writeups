#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid sillybox \
    --chdir /var/ctf/sillybox/ \
    --make-pidfile \
    --pidfile /var/ctf/sillybox//running.pid \
    --exec /usr/ctf/sillybox//sillybox_spawner
