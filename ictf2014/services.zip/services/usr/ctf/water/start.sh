#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid water \
    --chdir /var/ctf/water/ \
    --make-pidfile \
    --pidfile /var/ctf/water//running.pid \
    --exec /usr/ctf/water//water.py
