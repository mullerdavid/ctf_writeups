#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/talkun//running.pid
