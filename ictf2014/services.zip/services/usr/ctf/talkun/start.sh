#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid talkun \
    --chdir /var/ctf/talkun/ \
    --make-pidfile \
    --pidfile /var/ctf/talkun//running.pid \
    --exec /usr/ctf/talkun//talkun
