#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid mailgateway \
    --chdir /var/ctf/mailgateway/ \
    --make-pidfile \
    --pidfile /var/ctf/mailgateway//running.pid \
    --exec /usr/ctf/mailgateway//mailgateway
