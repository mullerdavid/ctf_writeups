#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/mailgateway//running.pid
