#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid passwordverify \
    --chdir /var/ctf/passwordverify/ \
    --make-pidfile \
    --pidfile /var/ctf/passwordverify//running.pid \
    --exec /usr/ctf/passwordverify//passwordverify
