#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/passwordverify//running.pid
