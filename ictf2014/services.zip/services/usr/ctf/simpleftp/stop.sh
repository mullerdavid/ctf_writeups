#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/simpleftp//running.pid
