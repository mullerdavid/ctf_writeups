#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid simpleftp \
    --chdir /var/ctf/simpleftp/ \
    --make-pidfile \
    --pidfile /var/ctf/simpleftp//running.pid \
    --exec /usr/ctf/simpleftp//simpleftp
