#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid bassretard \
    --chdir /var/ctf/bassretard/ \
    --make-pidfile \
    --pidfile /var/ctf/bassretard//running.pid \
    --exec /usr/ctf/bassretard//bassretard
