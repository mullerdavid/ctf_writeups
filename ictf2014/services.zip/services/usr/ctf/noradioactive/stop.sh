pkill -u noradioactive
sleep 2
pkill -KILL -u noradioactive
