#!/bin/sh
while true; 
do 
cd /usr/ctf/curiosityblogging
nodejs blogger.js
done
