#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/echo//running.pid
