#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid echo \
    --chdir /var/ctf/echo/ \
    --make-pidfile \
    --pidfile /var/ctf/echo//running.pid \
    --exec /usr/ctf/echo//echo.py
