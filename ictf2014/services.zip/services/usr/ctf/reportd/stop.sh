#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/reportd//running.pid
