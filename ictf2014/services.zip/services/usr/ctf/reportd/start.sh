#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid reportd \
    --chdir /var/ctf/reportd/ \
    --make-pidfile \
    --pidfile /var/ctf/reportd//running.pid \
    --exec /usr/ctf/reportd//reportd
