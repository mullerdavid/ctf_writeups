pkill -u webasstard
sleep 2
pkill -KILL -u webasstard
