cd /usr/ctf/webasstard
/sbin/start-stop-daemon -b --start --chdir /var/ctf/webasstard --exec /usr/ctf/webasstard/webasstard -- --servername 0.0.0.0
