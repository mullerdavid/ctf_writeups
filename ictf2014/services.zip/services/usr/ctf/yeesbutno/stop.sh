pkill -u yeesbutno
sleep 2
pkill -KILL -u yeesbutno
