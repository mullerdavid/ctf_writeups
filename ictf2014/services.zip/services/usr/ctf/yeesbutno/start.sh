cd /usr/ctf/yeesbutno
/sbin/start-stop-daemon -b --start --chdir /usr/ctf/yeesbutno --exec /usr/ctf/yeesbutno/yeesbutno 3336 --

