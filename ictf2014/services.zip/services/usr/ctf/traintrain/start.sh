cd /usr/ctf/traintrain
/sbin/start-stop-daemon -b --start --chdir /var/ctf/traintrain --exec /usr/bin/python /usr/ctf/traintrain/traintrain --
