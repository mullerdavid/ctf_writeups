pkill -u traintrain
sleep 2
pkill -KILL -u traintrain
