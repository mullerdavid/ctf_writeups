cd /usr/ctf/mathconsole
/sbin/start-stop-daemon -b --start --chdir /var/ctf/mathconsole --name mathconsole --exec /usr/bin/python /usr/ctf/mathconsole/mathconsole.pyc --
