pkill -u mathconsole
sleep 2
pkill -KILL -u mathconsole
