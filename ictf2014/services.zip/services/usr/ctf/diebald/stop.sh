#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/diebald//running.pid
