#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid diebald \
    --chdir /var/ctf/diebald/ \
    --make-pidfile \
    --pidfile /var/ctf/diebald//running.pid \
    --exec /usr/ctf/diebald//httpserver.py
