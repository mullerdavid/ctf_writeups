#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid smsgateway \
    --chdir /var/ctf/smsgateway/ \
    --make-pidfile \
    --pidfile /var/ctf/smsgateway//running.pid \
    --exec /usr/ctf/smsgateway//smsgateway
