#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/driller//running.pid
