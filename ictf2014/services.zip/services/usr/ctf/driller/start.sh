#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid driller \
    --chdir /var/ctf/driller/ \
    --make-pidfile \
    --pidfile /var/ctf/driller//running.pid \
    --exec /usr/ctf/driller//ude
