pkill -u poipoi
sleep 2
pkill -KILL -u poipoi
