cd /usr/ctf/poipoi
/sbin/start-stop-daemon -b --start --name poipoi --chdir /var/ctf/poipoi --exec /usr/ctf/poipoi/poipoi 3335 --
