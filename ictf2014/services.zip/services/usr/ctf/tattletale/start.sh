#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid tattletale \
    --chdir /var/ctf/tattletale/ \
    --make-pidfile \
    --pidfile /var/ctf/tattletale//running.pid \
    --exec /usr/ctf/tattletale//tattletale
