#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/tattletale//running.pid
