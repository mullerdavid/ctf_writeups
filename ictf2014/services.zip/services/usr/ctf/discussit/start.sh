#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid discussit \
    --chdir /var/ctf/discussit/ \
    --make-pidfile \
    --pidfile /var/ctf/discussit//running.pid \
    --exec /usr/ctf/discussit//discussit
