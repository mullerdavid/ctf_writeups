#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid sendalert \
    --chdir /var/ctf/sendalert/ \
    --make-pidfile \
    --pidfile /var/ctf/sendalert//running.pid \
    --exec /usr/ctf/sendalert//sendalert_main
