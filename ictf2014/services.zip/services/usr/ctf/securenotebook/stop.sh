pkill -u securenotebook
sleep 2
pkill -KILL -u securenotebook
