cd /usr/ctf/securenotebook
/sbin/start-stop-daemon -b --start --chdir /var/ctf/securenotebook --exec /usr/ctf/securenotebook/securenotebook 2190 --

