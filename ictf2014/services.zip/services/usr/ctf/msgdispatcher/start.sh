#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid msgdispatcher \
    --chdir /var/ctf/msgdispatcher/ \
    --make-pidfile \
    --pidfile /var/ctf/msgdispatcher//running.pid \
    --exec /usr/ctf/msgdispatcher//msgdispatcher_main
