#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/ccauthd//running.pid
