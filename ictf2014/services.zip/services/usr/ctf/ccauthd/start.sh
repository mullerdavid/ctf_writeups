#!/bin/sh
/sbin/start-stop-daemon \
    --background \
    --start \
    --chuid ccauthd \
    --chdir /var/ctf/ccauthd/ \
    --make-pidfile \
    --pidfile /var/ctf/ccauthd//running.pid \
    --exec /usr/ctf/ccauthd//ccauthd
