#!/bin/sh
cd /usr/ctf/stockjobber
exec ./stockjobber
