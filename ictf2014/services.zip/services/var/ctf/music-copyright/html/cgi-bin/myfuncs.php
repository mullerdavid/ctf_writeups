<?php 
function myheader($title) 
{
  print "<?xml version=\"1.0\" encoding=\"utf-8\"?><!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"    \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><head>  <meta name=\"generator\" content=  \"HTML Tidy for Mac OS X (vers 1 September 2005), see www.w3.org\" />  <meta http-equiv=\"Content-Type\" content=  \"text/html; charset=us-ascii\" />  <meta name=\"Generator\" content=\"iWeb 2.0.2\" />  <meta name=\"iWeb-Build\" content=\"local-build-20071203\" />  <meta name=\"viewport\" content=\"width=700\" />  <title>THE MAFIA Music and Film Industry Association - ${title}</title>  <link rel=\"stylesheet\" type=\"text/css\" media=\"screen,print\" href=  \"/music-copyright/Site/simple_files/simple.css\" />  <!--[if IE]><link rel='stylesheet' type='text/css' media='screen,print' href='/music-copyright/Site/simple_files/simpleIE.css'/><![endif]--><style type=\"text/css\">/*<![CDATA[*/        @import \"/music-copyright/Site/Scripts/Widgets/HTMLRegion/Paste.css\";/*]]>*/</style><script type=\"text/javascript\" src=\"/music-copyright/Site/Scripts/iWebSite.js\"></script><script type=\"text/javascript\" src=\"/music-copyright/Site/Scripts/Widgets/SharedResources/WidgetCommon.js\"></script><script type=\"text/javascript\" src=\"/music-copyright/Site/Scripts/Widgets/Navbar/navbar.js\"></script><script type=\"text/javascript\" src=\"/music-copyright/Site/Scripts/iWebImage.js\"></script><script type=\"text/javascript\" src=\"/music-copyright/Site/Scripts/Widgets/HTMLRegion/Paste.js\"></script><script type=\"text/javascript\" src=\"/music-copyright/Site/simple_files/simple.js\"></script></head><body style=\"background: #131010; margin: 0pt;\" onload=\"onPageLoad();\" onunload=\"onPageUnload();\">  <div style=\"text-align: center;\">    <div style=    \"margin-bottom: 0px; margin-left: auto; margin-right: auto; margin-top: 0px; overflow: hidden; position: relative; word-wrap: break-word; text-align: left; width: 700px;\"    id=\"body_content\">      <div style=      \"background: transparent url(/music-copyright/Site/simple_files/rp_tile_v6.jpg) repeat scroll top left; width: 700px;\">      <div style=      \"height: 139px; margin-left: 0px; position: relative; width: 700px; z-index: 10;\"        id=\"header_layer\">          <div style=\"height: 0px; line-height: 0px;\" class=          \"bumper\">            &nbsp;&nbsp;          </div>          <div style=          \"height: 139px; width: 636px; height: 139px; left: 32px; position: absolute; top: 0px; width: 635px; z-index: 1;\"          class=\"tinyText\">            <div style=\"position: relative; width: 635px;\">              <img src=\"/music-copyright/Site/simple_files/shapeimage_1.png\" alt=\"\"              style=\"height: 107px; left: 0px; margin-left: -1px; margin-top: 24px; position: absolute; top: 0px; width: 471px;\" />            </div>          </div>        </div>        <div style=        \"margin-left: 0px; position: relative; width: 700px; z-index: 0;\"        id=\"nav_layer\">          <div style=\"height: 0px; line-height: 0px;\" class=          \"bumper\">            &nbsp;&nbsp;          </div>          <div style=          \"height: 490px; width: 700px; height: 490px; left: 0px; position: absolute; top: -489px; width: 700px; z-index: 1;\"          class=\"tinyText style_SkipStroke\">            <img src=\"/music-copyright/Site/simple_files/navfill-v2.jpg\" alt=\"\" style=            \"border: none; height: 490px; width: 700px;\" />          </div>          <div style=\"height: 1px; line-height: 1px;\" class=          \"tinyText\">            &nbsp;&nbsp;          </div>          <div class=\"com-apple-iweb-widget-navbar flowDefining\"          id=\"widget0\" style=          \"margin-left: 0px; margin-top: -1px; position: relative; width: 700px; z-index: 1;\">          <div id=\"widget0-navbar\" class=\"navbar\">              <div id=\"widget0-bg\" class=\"navbar-bg\">                <ul id=\"widget0-navbar-list\" class=\"navbar-list\">                </ul>              </div>            </div>          </div><script type=\"text/javascript\"><!--//--><![CDATA[//><!--new NavBar('widget0', '/music-copyright/Site/Scripts/Widgets/Navbar', '/music-copyright/Site/Scripts/Widgets/SharedResources', '.', {\"current-page-GUID\": \"2DC90489-4C6A-49B1-BF0B-2DD72F879CA7\", \"path-to-root\": \"\", \"isCollectionPage\": \"NO\", \"navbar-css\": \".navbar {\n\tfont-family: 'Courier New', Courier, monospace, serif;\n\tfont-size: 1.1em;\n\tcolor: #AFAA9F;\n\tmargin: -2px 0 0 0px;\n\tline-height: 20px;\n\tpadding: 5px 0 12px 0;\n\tfont-weight: bold;\n\tbackground-image: url(/music-copyright/Site/simple_files\/navfill-v2_1.jpg);\n}\n\n.navbar-bg {\n\ttext-align: left;\n}\n\n.navbar-bg ul {\n\tlist-style: none;\n\tmargin: 0px;\n\tpadding: 0 10px 0 30px;\n}\n\n\nli {\n\tlist-style-type: none;\n\tdisplay: inline;\n\tpadding: 0px 25px 0 0;\n}\n\n\nli a {\n\ttext-decoration: none;\n\tcolor: #AFAA9F;\n}\n\nli a:visited {\n\ttext-decoration: none;\n\tcolor: #AFAA9F;\n}\n\nli a:hover\n{\n \tcolor: #D64600;\n}\n\n\nli.current-page a\n{\n\t color: #fff;\n\n}\n\"});//--><!]]></script>          <div style=\"clear: both; height: 0px; line-height: 0px;\"          class=\"spacer\">            &nbsp;&nbsp;          </div>        </div>        <div style=        \"margin-left: 0px; position: relative; width: 700px; z-index: 5;\"        id=\"body_layer\">          <div style=\"height: 0px; line-height: 0px;\" class=          \"bumper\">            &nbsp;&nbsp;          </div>          <div style=          \"height: 25px; width: 700px; height: 25px; left: 0px; position: absolute; top: -15px; width: 700px; z-index: 1;\"          class=\"tinyText style_SkipStroke_1\">            <img src=\"/music-copyright/Site/simple_files/pagetop10.png\" alt=\"\" style=            \"border: none; height: 25px; width: 700px;\" />          </div>          <div id=\"id3\" style=          \"height: 196px; left: 109px; position: absolute; top: 105px; width: 400px; z-index: 1;\"          class=\"style_SkipStroke_2\">            <div class=            \"text-content graphic_textbox_layout_style_default_External_174_196\"            style=\"padding: 0px;\">              <div class=\"graphic_textbox_layout_style_default\">                <p style=\"padding-bottom: 0pt; padding-top: 0pt;\"                class=\"Body\">";
}

function myfooter() {
  print "</p>                <p><a href=\"/music-copyright/Sound_of_music.html\">Go Back</a></p>              </div>            </div>          </div>          <div style=\"height: 600px; line-height: 600px;\" class=          \"spacer\">            &nbsp;&nbsp;          </div>        </div>        <div style=        \"height: 100px; margin-left: 0px; position: relative; width: 700px; z-index: 15;\"        id=\"footer_layer\">          <div style=\"height: 0px; line-height: 0px;\" class=          \"bumper\"> &nbsp;&nbsp;          </div>        </div>      </div>    </div>  </div></body></html>";
}


function diefooter($msg) {
  print "<p><b>An error occurred:</b></p>\n";
  print "<p>${msg}</p>\n";
  myfooter();
  die();
}

function gencookie($email, $password, $host) {
  if (($email == "") || ($password == "") || ($host == "")) {
    return "";
  }
  $str =  "MAFIA" . ":" . $host;
  $len = strlen($str);
  for ($i = 0; $i < $len; $i++) {
    $str[$i] = $str[$i] ^ $password[$i % strlen($password)];
  }
  return $email . ":" . $len . ":" . base64_encode($str);
}

function decryptcookie($cookie, $password) {
  if (($password == "") || ($cookie == "")) {
    return "";
  }
  list($email, $len, $enc) = split(':', $cookie);
  if (isset($debug) and $debug) {
    print "<p>Cookie = " . $cookie . "</p>";
    print "<p>Encoded auth = " . $enc . "</p>";
    print "<p>Email = " . $email . "</p>";
  }

  $str = base64_decode($enc);
  for ($i = 0; $i < $len; $i++) {
    $str[$i] = $str[$i] ^ $password[$i % strlen($password)];
  }

  if (isset($debug) and $debug) {
    print "<p>Decrypted cookie is: " . $str . "</p>";
    print "<p>Magic is: " . substr($str, 0, 5) . "</p>";
  }
  if (strcmp(substr($str, 0, 5), "MAFIA") != 0) {
    return "";
  }
  list($mafia, $host) = split(':', $str, 3);
  if (isset($debug) and $debug) {
    print "<p>Host is: " . $host . "</p>";
    print "<p>Email is: " . $email . "</p>";
    print "<p>Magic is: " . $mafia . "</p>";
  }
  return $host;
}

function cookietoenv() {

  foreach($_COOKIE as $key => $value) {
    if (isset($debug) and $debug) {
      print "<p>Putting $key=$value in the environment</p>";
    }
    putenv("$key=$value");
  }
}

function checkcookie($email, $auth, $host) {
  if (($email == "") || ($auth == "") || ($host == "")) {
    return -1;
  }
  $fh = fopen("./accounts/" . $email, "r"); 
  if (!$fh) {
    return -1; 
  }
  $last = trim(fgets($fh));
  $first = trim(fgets($fh));
  $pass = trim(fgets($fh));
  
  $cookiehost = decryptcookie($auth, $pass);
  
  if ($cookiehost == "") {
    return -1;
  }

  if ($host != $cookiehost) {
    return 1;
  }
  
  return 0;
}

function getusername($email) {
  if ($email == "") {
    return "";
  }
  $fh = fopen("./accounts/" . $email, "r"); 
  if (!$fh) {
    return -1; 
  }
  $last = trim(fgets($fh));
  $first = trim(fgets($fh));

  return $first;
}

function getlastname($email) {
  if ($email == "") {
    return "";
  }
  $fh = fopen("./accounts/" . $email, "r"); 
  if (!$fh) {
    return -1; 
  }
  $last = trim(fgets($fh));

  return $last;
}
?>
