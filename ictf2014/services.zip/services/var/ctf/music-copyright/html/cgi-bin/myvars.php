<?php
if (isset($_GET['debug'])) {
  $debug = true;
 } else {
  $debug = false;
 }
?>
