package main

import (
	dilithium5 "crypto/pqc/dilithium/dilithium5"
	"crypto/rand"
	"crypto/sm4"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/asn1"
	"encoding/base64"
	"encoding/pem"
	"fmt"
	"log"
	"math/big"
	"net"
	"time"
)

const (
	port = "1337"
	flag = "HCSC{fake_flag}"
)

type pkcs8 struct {
	Version    int
	Algo       pkix.AlgorithmIdentifier
	PrivateKey []byte
}

func main() {
	privateKey, publicKey, err := generateKeyPair()
	if err != nil {
		log.Printf("Failed to generate key pair: %v\n", err)
		return
	}

	fmt.Printf("Private key: %v\n", privateKey)
	fmt.Printf("Public key: %v\n", publicKey)

	cert, err := generateCertificate(privateKey, publicKey)
	if err != nil {
		log.Fatalf("Failed to generate certificate: %v\n", err)
	}

	startSecureServer(cert)
}

func obtainKey() (string, error) {
	conn, err := net.DialTimeout("tcp", "capturemeifyoucan-backend:7331", 2*time.Second)
	if err != nil {
		return "", fmt.Errorf("Failed to connect to key provider: %v", err)
	}

	key := make([]byte, 1024)
	n, err := conn.Read(key)
	if err != nil {
		return "", fmt.Errorf("Failed to read key: %v", err)
	}

	return string(key[:n]), nil
}

func startSecureServer(cert tls.Certificate) {
	config := &tls.Config{
		Certificates: []tls.Certificate{cert},
		MinVersion:   tls.VersionTLS13,
		MaxVersion:   tls.VersionTLS13,
		CipherSuites: []uint16{
			tls.TLS_AES_128_GCM_SHA256,
			tls.TLS_AES_256_GCM_SHA384,
		},
	}

	listener, err := tls.Listen("tcp", ":"+port, config)
	defer listener.Close()

	if err != nil {
		log.Fatalf("Failed to start secure server: %v", err)
	}

	log.Printf("Secure server listening on port %s\n", port)
	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Printf("Failed to accept connection: %v", err)
			continue
		}

		go handleConnection(conn)
	}
}

func encryptData(data string) string {
	key := []byte("radiofrequencies")

	encrypted, err := sm4.Sm4Cbc(key, []byte(data), true)
	if err != nil {
		log.Fatalf("Failed to encrypt password: %v", err)
	}

	return base64.StdEncoding.EncodeToString(encrypted)
}

func handleConnection(conn net.Conn) {
	defer conn.Close()

	log.Printf("Client connected from %s\n", conn.RemoteAddr())

	clientKey, err := obtainKey()
	if err != nil {
		log.Printf("Failed to obtain key from key provider: %v", err)
		_, _ = conn.Write([]byte("Failed to obtain key from key provider\n"))
		return
	}
	_, err = conn.Write([]byte(encryptData(clientKey) + "\n"))
	if err != nil {
		log.Printf("Failed to send password to client: %v", err)
		return
	}

	log.Printf("Password sent to client at %s\n", conn.RemoteAddr())
}

func generateKeyPair() (*dilithium5.PrivateKey, *dilithium5.PublicKey, error) {
	privateKey, err := dilithium5.GenerateKey()
	if err != nil {
		log.Printf("Failed to generate key pair: %v\n", err)
		return nil, nil, err
	}

	return privateKey, &privateKey.PublicKey, nil
}

func convertKey(key, pubKey []byte) ([]byte, error) {
	pkcs8Key := pkcs8{
		Version: 0,
		Algo: pkix.AlgorithmIdentifier{
			Algorithm:  asn1.ObjectIdentifier{1, 5, 1, 2},
			Parameters: asn1.RawValue{Bytes: pubKey},
		},
		PrivateKey: key,
	}

	asn1PKCS8, err := asn1.Marshal(pkcs8Key)
	if err != nil {
		return nil, err
	}

	return asn1PKCS8, nil
}
func writeKey(key []byte) []byte {
	pemBlock := &pem.Block{
		Type:  "PRIVATE KEY",
		Bytes: key,
	}
	pemBytes := pem.EncodeToMemory(pemBlock)

	return pemBytes
}

func generateCertificate(privateKey *dilithium5.PrivateKey, publicKey *dilithium5.PublicKey) (tls.Certificate, error) {
	notBefore := time.Now()
	notAfter := notBefore.Add(365 * 24 * time.Hour)

	serialNumber, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 159))
	if err != nil {
		return tls.Certificate{}, fmt.Errorf("failed to generate serial number: %v", err)
	}

	template := x509.Certificate{
		SerialNumber: serialNumber,
		Subject: pkix.Name{
			Organization: []string{"Honeylab"},
		},
		DNSNames:              []string{flag},
		NotBefore:             notBefore,
		NotAfter:              notAfter,
		KeyUsage:              x509.KeyUsageKeyEncipherment | x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}

	pkcs8Key, err := convertKey(privateKey.Sk, publicKey.Pk)
	if err != nil {
		return tls.Certificate{}, fmt.Errorf("failed to convert key pair: %v", err)
	}

	keyPEM := writeKey(pkcs8Key)

	certDER, err := x509.CreateCertificate(rand.Reader, &template, &template, &privateKey.PublicKey, privateKey)
	if err != nil {
		return tls.Certificate{}, fmt.Errorf("failed to create certificate: %v", err)
	}

	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})

	fmt.Printf("Certificate:\n%s\n", certPEM)
	fmt.Printf("Private key:\n%s\n", keyPEM)

	return tls.X509KeyPair(certPEM, keyPEM)
}
