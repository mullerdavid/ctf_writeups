package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"log"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"
)

const (
	certFolder   = "./certs"
	certFileName = "server.crt"
	keyFileName  = "server.key"
	flag         = "HCSC{fake_flag}"
)

var (
	clientPrivKey  ed25519.PrivateKey
	clientCert     []byte
	mu             sync.RWMutex
	clientCertPool *x509.CertPool
)

func main() {
	err := os.MkdirAll(certFolder, os.ModePerm)
	if err != nil {
		log.Fatalf("Failed to create cert directory: %v", err)
	}

	certPath := filepath.Join(certFolder, certFileName)
	keyPath := filepath.Join(certFolder, keyFileName)
	_, certErr := os.Stat(certPath)
	_, keyErr := os.Stat(keyPath)

	if os.IsNotExist(certErr) || os.IsNotExist(keyErr) {
		log.Println("Certificates not found, generating new ones...")
		err := generateSelfSignedCert(certPath, keyPath)
		if err != nil {
			log.Fatalf("Failed to generate certificates: %v", err)
		}
	} else {
		log.Println("Existing certificates found, using them.")
	}

	err = generateClientCertificate()
	if err != nil {
		log.Fatalf("Failed to generate client certificate: %v", err)
	}

	go startTCPService()

	http.HandleFunc("/api/v1/flag", func(w http.ResponseWriter, r *http.Request) {
		if r.TLS == nil || len(r.TLS.PeerCertificates) == 0 {
			http.Error(w, "Client certificate required", http.StatusUnauthorized)
			return
		}
		w.Header().Set("Content-Type", "text/plain")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(flag))
	})

	log.Println("Starting server on https://localhost:8443")
	srv := &http.Server{
		Addr:    ":8443",
		Handler: nil,
		TLSConfig: &tls.Config{
			MinVersion:       tls.VersionTLS13,
			CurvePreferences: []tls.CurveID{tls.X25519MLKEM768},
			ClientCAs:        clientCertPool,
			ClientAuth:       tls.RequireAndVerifyClientCert,
		},
	}

	log.Fatal(srv.ListenAndServeTLS(certPath, keyPath))
}

func generateSelfSignedCert(certPath, keyPath string) error {
	pubKey, privKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return fmt.Errorf("failed to generate key pair: %w", err)
	}

	notBefore := time.Now()
	notAfter := notBefore.Add(365 * 24 * time.Hour)

	serialNumber, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if err != nil {
		return fmt.Errorf("failed to generate serial number: %w", err)
	}

	template := x509.Certificate{
		SerialNumber: serialNumber,
		Subject: pkix.Name{
			Organization: []string{"Honeylab"},
		},
		NotBefore:             notBefore,
		NotAfter:              notAfter,
		KeyUsage:              x509.KeyUsageKeyEncipherment | x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}

	certDER, err := x509.CreateCertificate(rand.Reader, &template, &template, pubKey, privKey)
	if err != nil {
		return fmt.Errorf("failed to create certificate: %w", err)
	}

	certFile, err := os.Create(certPath)
	if err != nil {
		return fmt.Errorf("failed to open %s for writing: %w", certPath, err)
	}
	defer certFile.Close()

	if err := pem.Encode(certFile, &pem.Block{Type: "CERTIFICATE", Bytes: certDER}); err != nil {
		return fmt.Errorf("failed to write data to cert.pem: %w", err)
	}

	keyFile, err := os.Create(keyPath)
	if err != nil {
		return fmt.Errorf("failed to open %s for writing: %w", keyPath, err)
	}
	defer keyFile.Close()

	privBytes, err := x509.MarshalPKCS8PrivateKey(privKey)
	if err != nil {
		return fmt.Errorf("unable to marshal private key: %w", err)
	}
	if err := pem.Encode(keyFile, &pem.Block{Type: "PRIVATE KEY", Bytes: privBytes}); err != nil {
		return fmt.Errorf("failed to write data to key.pem: %w", err)
	}

	log.Printf("Generated certificate and key at %s and %s\n", certPath, keyPath)
	return nil
}

func generateClientCertificate() error {
	pubKey, privKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return fmt.Errorf("failed to generate client key pair: %w", err)
	}

	notBefore := time.Now()
	notAfter := notBefore.Add(365 * 24 * time.Hour)

	serialNumber, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if err != nil {
		return fmt.Errorf("failed to generate serial number: %w", err)
	}

	template := x509.Certificate{
		SerialNumber: serialNumber,
		Subject: pkix.Name{
			CommonName: "client",
		},
		NotBefore:             notBefore,
		NotAfter:              notAfter,
		KeyUsage:              x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth},
		BasicConstraintsValid: true,
	}

	certDER, err := x509.CreateCertificate(rand.Reader, &template, &template, pubKey, privKey)
	if err != nil {
		return fmt.Errorf("failed to create client certificate: %w", err)
	}

	newPool := x509.NewCertPool()
	newPool.AppendCertsFromPEM(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER}))

	mu.Lock()
	defer mu.Unlock()
	clientPrivKey = privKey
	clientCert = certDER
	clientCertPool = newPool

	return nil
}

func startTCPService() {
	listener, err := net.Listen("tcp", ":7331")
	if err != nil {
		log.Fatalf("Failed to start TCP service: %v", err)
	}
	defer listener.Close()
	log.Println("Started TCP service on localhost:7331")

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Printf("Failed to accept TCP connection: %v", err)
			continue
		}

		go func(conn net.Conn) {
			defer conn.Close()
			mu.RLock()
			defer mu.RUnlock()

			if clientPrivKey == nil {
				_, _ = conn.Write([]byte("No client private key available\n"))
				return
			}

			privBytes, err := x509.MarshalPKCS8PrivateKey(clientPrivKey)
			if err != nil {
				log.Printf("Failed to marshal private key: %v", err)
				_, _ = conn.Write([]byte("Error marshaling private key\n"))
				return
			}

			privPemBytes := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: privBytes})
			certPemBytes := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: clientCert})

			_, err = conn.Write(append(privPemBytes, certPemBytes...))
			if err != nil {
				log.Printf("Failed to send client key and certificate: %v", err)
				return
			}
		}(conn)
	}
}
