from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.analog_channel import AnalogChannel
    from ..models.board_info_eth import BoardInfoEth
    from ..models.digital_channel import DigitalChannel


T = TypeVar("T", bound="BoardInfo")


@attr.s(auto_attribs=True)
class BoardInfo:
    """
    Attributes:
        board_name (str):
        channels (List[Union['AnalogChannel', 'DigitalChannel']]):
        sampling_rates (List[int]):
        firmware (Union[Unset, str]):
        link (Union[Unset, str]):
        hostname (Union[Unset, str]):
        eth (Union[Unset, BoardInfoEth]):
    """

    board_name: str
    channels: List[Union["AnalogChannel", "DigitalChannel"]]
    sampling_rates: List[int]
    firmware: Union[Unset, str] = UNSET
    link: Union[Unset, str] = UNSET
    hostname: Union[Unset, str] = UNSET
    eth: Union[Unset, "BoardInfoEth"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        from ..models.analog_channel import AnalogChannel

        board_name = self.board_name
        channels = []
        for channels_item_data in self.channels:
            channels_item: Dict[str, Any]

            if isinstance(channels_item_data, AnalogChannel):
                channels_item = channels_item_data.to_dict()

            else:
                channels_item = channels_item_data.to_dict()

            channels.append(channels_item)

        sampling_rates = self.sampling_rates

        firmware = self.firmware
        link = self.link
        hostname = self.hostname
        eth: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.eth, Unset):
            eth = self.eth.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "boardName": board_name,
                "channels": channels,
                "samplingRates": sampling_rates,
            }
        )
        if firmware is not UNSET:
            field_dict["firmware"] = firmware
        if link is not UNSET:
            field_dict["link"] = link
        if hostname is not UNSET:
            field_dict["hostname"] = hostname
        if eth is not UNSET:
            field_dict["eth"] = eth

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.analog_channel import AnalogChannel
        from ..models.board_info_eth import BoardInfoEth
        from ..models.digital_channel import DigitalChannel

        d = src_dict.copy()
        board_name = d.pop("boardName")

        channels = []
        _channels = d.pop("channels")
        for channels_item_data in _channels:

            def _parse_channels_item(data: object) -> Union["AnalogChannel", "DigitalChannel"]:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    componentsschemaschannel_type_0 = AnalogChannel.from_dict(data)

                    return componentsschemaschannel_type_0
                except:  # noqa: E722
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemaschannel_type_1 = DigitalChannel.from_dict(data)

                return componentsschemaschannel_type_1

            channels_item = _parse_channels_item(channels_item_data)

            channels.append(channels_item)

        sampling_rates = cast(List[int], d.pop("samplingRates"))

        firmware = d.pop("firmware", UNSET)

        link = d.pop("link", UNSET)

        hostname = d.pop("hostname", UNSET)

        _eth = d.pop("eth", UNSET)
        eth: Union[Unset, BoardInfoEth]
        if isinstance(_eth, Unset):
            eth = UNSET
        else:
            eth = BoardInfoEth.from_dict(_eth)

        board_info = cls(
            board_name=board_name,
            channels=channels,
            sampling_rates=sampling_rates,
            firmware=firmware,
            link=link,
            hostname=hostname,
            eth=eth,
        )

        board_info.additional_properties = d
        return board_info

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
