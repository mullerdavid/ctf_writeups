from enum import Enum


class TriggerConfigurationTrigger(str, Enum):
    BOTH = "both"
    FALLING = "falling"
    RISING = "rising"

    def __str__(self) -> str:
        return str(self.value)
