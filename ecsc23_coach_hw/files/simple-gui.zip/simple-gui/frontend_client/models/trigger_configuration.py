from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.channel_type import ChannelType
from ..models.trigger_configuration_trigger import TriggerConfigurationTrigger
from ..types import UNSET, Unset

T = TypeVar("T", bound="TriggerConfiguration")


@attr.s(auto_attribs=True)
class TriggerConfiguration:
    """
    Attributes:
        channel_type (Union[Unset, ChannelType]):
        channel_id (Union[Unset, int]):
        trigger (Union[Unset, TriggerConfigurationTrigger]):
        trigger_delay (Union[Unset, int]): Number of samples 'till mid of sample buffer
    """

    channel_type: Union[Unset, ChannelType] = UNSET
    channel_id: Union[Unset, int] = UNSET
    trigger: Union[Unset, TriggerConfigurationTrigger] = UNSET
    trigger_delay: Union[Unset, int] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        channel_type: Union[Unset, str] = UNSET
        if not isinstance(self.channel_type, Unset):
            channel_type = self.channel_type.value

        channel_id = self.channel_id
        trigger: Union[Unset, str] = UNSET
        if not isinstance(self.trigger, Unset):
            trigger = self.trigger.value

        trigger_delay = self.trigger_delay

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if channel_type is not UNSET:
            field_dict["channelType"] = channel_type
        if channel_id is not UNSET:
            field_dict["channelId"] = channel_id
        if trigger is not UNSET:
            field_dict["trigger"] = trigger
        if trigger_delay is not UNSET:
            field_dict["triggerDelay"] = trigger_delay

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _channel_type = d.pop("channelType", UNSET)
        channel_type: Union[Unset, ChannelType]
        if isinstance(_channel_type, Unset):
            channel_type = UNSET
        else:
            channel_type = ChannelType(_channel_type)

        channel_id = d.pop("channelId", UNSET)

        _trigger = d.pop("trigger", UNSET)
        trigger: Union[Unset, TriggerConfigurationTrigger]
        if isinstance(_trigger, Unset):
            trigger = UNSET
        else:
            trigger = TriggerConfigurationTrigger(_trigger)

        trigger_delay = d.pop("triggerDelay", UNSET)

        trigger_configuration = cls(
            channel_type=channel_type,
            channel_id=channel_id,
            trigger=trigger,
            trigger_delay=trigger_delay,
        )

        trigger_configuration.additional_properties = d
        return trigger_configuration

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
