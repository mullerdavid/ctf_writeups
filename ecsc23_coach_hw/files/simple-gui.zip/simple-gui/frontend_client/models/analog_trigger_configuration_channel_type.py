from enum import Enum


class AnalogTriggerConfigurationChannelType(str, Enum):
    ANALOG = "analog"

    def __str__(self) -> str:
        return str(self.value)
