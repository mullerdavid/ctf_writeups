from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.board_info import BoardInfo
    from ..models.slot_info import SlotInfo


T = TypeVar("T", bound="Connection")


@attr.s(auto_attribs=True)
class Connection:
    """
    Attributes:
        board (BoardInfo):
        slot (Union[Unset, SlotInfo]):
    """

    board: "BoardInfo"
    slot: Union[Unset, "SlotInfo"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        board = self.board.to_dict()

        slot: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.slot, Unset):
            slot = self.slot.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "board": board,
            }
        )
        if slot is not UNSET:
            field_dict["slot"] = slot

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.board_info import BoardInfo
        from ..models.slot_info import SlotInfo

        d = src_dict.copy()
        board = BoardInfo.from_dict(d.pop("board"))

        _slot = d.pop("slot", UNSET)
        slot: Union[Unset, SlotInfo]
        if isinstance(_slot, Unset):
            slot = UNSET
        else:
            slot = SlotInfo.from_dict(_slot)

        connection = cls(
            board=board,
            slot=slot,
        )

        connection.additional_properties = d
        return connection

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
