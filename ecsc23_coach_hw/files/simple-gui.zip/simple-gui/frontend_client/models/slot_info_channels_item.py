from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.channel_type import ChannelType
from ..types import UNSET, Unset

T = TypeVar("T", bound="SlotInfoChannelsItem")


@attr.s(auto_attribs=True)
class SlotInfoChannelsItem:
    """
    Attributes:
        channel_type (Union[Unset, ChannelType]):
        channel_id (Union[Unset, int]):
        name (Union[Unset, str]):
        description (Union[Unset, str]):
    """

    channel_type: Union[Unset, ChannelType] = UNSET
    channel_id: Union[Unset, int] = UNSET
    name: Union[Unset, str] = UNSET
    description: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        channel_type: Union[Unset, str] = UNSET
        if not isinstance(self.channel_type, Unset):
            channel_type = self.channel_type.value

        channel_id = self.channel_id
        name = self.name
        description = self.description

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if channel_type is not UNSET:
            field_dict["channelType"] = channel_type
        if channel_id is not UNSET:
            field_dict["channelId"] = channel_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _channel_type = d.pop("channelType", UNSET)
        channel_type: Union[Unset, ChannelType]
        if isinstance(_channel_type, Unset):
            channel_type = UNSET
        else:
            channel_type = ChannelType(_channel_type)

        channel_id = d.pop("channelId", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        slot_info_channels_item = cls(
            channel_type=channel_type,
            channel_id=channel_id,
            name=name,
            description=description,
        )

        slot_info_channels_item.additional_properties = d
        return slot_info_channels_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
