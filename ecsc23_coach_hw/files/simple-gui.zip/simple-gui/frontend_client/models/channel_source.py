from enum import Enum


class ChannelSource(str, Enum):
    EXT = "ext"
    INT = "int"

    def __str__(self) -> str:
        return str(self.value)
