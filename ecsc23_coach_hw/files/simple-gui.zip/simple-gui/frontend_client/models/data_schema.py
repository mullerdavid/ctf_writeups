from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.data_schema_channels_item import DataSchemaChannelsItem


T = TypeVar("T", bound="DataSchema")


@attr.s(auto_attribs=True)
class DataSchema:
    """
    Attributes:
        sample_rate (Union[Unset, int]):
        stride (Union[Unset, int]):
        offset (Union[Unset, int]): relative offset within this sample, i.e. the input parameter passed back in, in
            samples, not factoring in stride
        trigger_offset (Union[Unset, int]): trigger offset applied to the sample, as above, i.e. offset of the trigger
            from the center of the full sample (fullsize/2)
        samples (Union[Unset, int]): number of samples in the data (have a distance of `stride` to each other)
        fullsize (Union[Unset, int]): Full size of the sample in number of samples. Currently fixed to 2**24
        channels (Union[Unset, List['DataSchemaChannelsItem']]):
    """

    sample_rate: Union[Unset, int] = UNSET
    stride: Union[Unset, int] = UNSET
    offset: Union[Unset, int] = UNSET
    trigger_offset: Union[Unset, int] = UNSET
    samples: Union[Unset, int] = UNSET
    fullsize: Union[Unset, int] = UNSET
    channels: Union[Unset, List["DataSchemaChannelsItem"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        sample_rate = self.sample_rate
        stride = self.stride
        offset = self.offset
        trigger_offset = self.trigger_offset
        samples = self.samples
        fullsize = self.fullsize
        channels: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.channels, Unset):
            channels = []
            for channels_item_data in self.channels:
                channels_item = channels_item_data.to_dict()

                channels.append(channels_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if sample_rate is not UNSET:
            field_dict["sampleRate"] = sample_rate
        if stride is not UNSET:
            field_dict["stride"] = stride
        if offset is not UNSET:
            field_dict["offset"] = offset
        if trigger_offset is not UNSET:
            field_dict["triggerOffset"] = trigger_offset
        if samples is not UNSET:
            field_dict["samples"] = samples
        if fullsize is not UNSET:
            field_dict["fullsize"] = fullsize
        if channels is not UNSET:
            field_dict["channels"] = channels

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.data_schema_channels_item import DataSchemaChannelsItem

        d = src_dict.copy()
        sample_rate = d.pop("sampleRate", UNSET)

        stride = d.pop("stride", UNSET)

        offset = d.pop("offset", UNSET)

        trigger_offset = d.pop("triggerOffset", UNSET)

        samples = d.pop("samples", UNSET)

        fullsize = d.pop("fullsize", UNSET)

        channels = []
        _channels = d.pop("channels", UNSET)
        for channels_item_data in _channels or []:
            channels_item = DataSchemaChannelsItem.from_dict(channels_item_data)

            channels.append(channels_item)

        data_schema = cls(
            sample_rate=sample_rate,
            stride=stride,
            offset=offset,
            trigger_offset=trigger_offset,
            samples=samples,
            fullsize=fullsize,
            channels=channels,
        )

        data_schema.additional_properties = d
        return data_schema

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
