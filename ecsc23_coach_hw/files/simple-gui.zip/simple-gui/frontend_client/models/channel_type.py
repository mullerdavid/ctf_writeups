from enum import Enum


class ChannelType(str, Enum):
    ANALOG = "analog"
    DIGITAL = "digital"

    def __str__(self) -> str:
        return str(self.value)
