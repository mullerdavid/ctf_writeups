from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.channel_type import ChannelType
from ..types import UNSET, Unset

T = TypeVar("T", bound="DataSchemaChannelsItem")


@attr.s(auto_attribs=True)
class DataSchemaChannelsItem:
    """
    Attributes:
        channel_type (Union[Unset, ChannelType]):
        channel_id (Union[Unset, int]):
        bits (Union[Unset, int]):
        gain (Union[Unset, int]): gain that was used while sampling
        bias (Union[Unset, int]): bias that was used while sampling
    """

    channel_type: Union[Unset, ChannelType] = UNSET
    channel_id: Union[Unset, int] = UNSET
    bits: Union[Unset, int] = UNSET
    gain: Union[Unset, int] = UNSET
    bias: Union[Unset, int] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        channel_type: Union[Unset, str] = UNSET
        if not isinstance(self.channel_type, Unset):
            channel_type = self.channel_type.value

        channel_id = self.channel_id
        bits = self.bits
        gain = self.gain
        bias = self.bias

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if channel_type is not UNSET:
            field_dict["channelType"] = channel_type
        if channel_id is not UNSET:
            field_dict["channelId"] = channel_id
        if bits is not UNSET:
            field_dict["bits"] = bits
        if gain is not UNSET:
            field_dict["gain"] = gain
        if bias is not UNSET:
            field_dict["bias"] = bias

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _channel_type = d.pop("channelType", UNSET)
        channel_type: Union[Unset, ChannelType]
        if isinstance(_channel_type, Unset):
            channel_type = UNSET
        else:
            channel_type = ChannelType(_channel_type)

        channel_id = d.pop("channelId", UNSET)

        bits = d.pop("bits", UNSET)

        gain = d.pop("gain", UNSET)

        bias = d.pop("bias", UNSET)

        data_schema_channels_item = cls(
            channel_type=channel_type,
            channel_id=channel_id,
            bits=bits,
            gain=gain,
            bias=bias,
        )

        data_schema_channels_item.additional_properties = d
        return data_schema_channels_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
