from enum import Enum


class AnalogChannelConfigurationType(str, Enum):
    ANALOG = "analog"

    def __str__(self) -> str:
        return str(self.value)
