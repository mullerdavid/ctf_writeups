from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.channel_source import ChannelSource
from ..models.digital_channel_configuration_type import DigitalChannelConfigurationType
from ..types import UNSET, Unset

T = TypeVar("T", bound="DigitalChannelConfiguration")


@attr.s(auto_attribs=True)
class DigitalChannelConfiguration:
    """
    Attributes:
        type (Union[Unset, DigitalChannelConfigurationType]):
        id (Union[Unset, int]):
        source (Union[Unset, ChannelSource]):
        enabled (Union[Unset, bool]): whether or not the channel data should be returned in the data stream
    """

    type: Union[Unset, DigitalChannelConfigurationType] = UNSET
    id: Union[Unset, int] = UNSET
    source: Union[Unset, ChannelSource] = UNSET
    enabled: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = self.type.value

        id = self.id
        source: Union[Unset, str] = UNSET
        if not isinstance(self.source, Unset):
            source = self.source.value

        enabled = self.enabled

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type is not UNSET:
            field_dict["type"] = type
        if id is not UNSET:
            field_dict["id"] = id
        if source is not UNSET:
            field_dict["source"] = source
        if enabled is not UNSET:
            field_dict["enabled"] = enabled

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _type = d.pop("type", UNSET)
        type: Union[Unset, DigitalChannelConfigurationType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = DigitalChannelConfigurationType(_type)

        id = d.pop("id", UNSET)

        _source = d.pop("source", UNSET)
        source: Union[Unset, ChannelSource]
        if isinstance(_source, Unset):
            source = UNSET
        else:
            source = ChannelSource(_source)

        enabled = d.pop("enabled", UNSET)

        digital_channel_configuration = cls(
            type=type,
            id=id,
            source=source,
            enabled=enabled,
        )

        digital_channel_configuration.additional_properties = d
        return digital_channel_configuration

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
