from enum import Enum


class BoardConfigSampling(str, Enum):
    BUSY = "busy"
    CONTINUOUS = "continuous"
    SINGLE = "single"
    STOP = "stop"

    def __str__(self) -> str:
        return str(self.value)
