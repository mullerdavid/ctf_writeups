from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.slot_info_channels_item import SlotInfoChannelsItem


T = TypeVar("T", bound="SlotInfo")


@attr.s(auto_attribs=True)
class SlotInfo:
    """
    Attributes:
        name (str):
        link (str):
        channels (List['SlotInfoChannelsItem']):
        serial (Union[Unset, float]):
    """

    name: str
    link: str
    channels: List["SlotInfoChannelsItem"]
    serial: Union[Unset, float] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        link = self.link
        channels = []
        for channels_item_data in self.channels:
            channels_item = channels_item_data.to_dict()

            channels.append(channels_item)

        serial = self.serial

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "link": link,
                "channels": channels,
            }
        )
        if serial is not UNSET:
            field_dict["serial"] = serial

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.slot_info_channels_item import SlotInfoChannelsItem

        d = src_dict.copy()
        name = d.pop("name")

        link = d.pop("link")

        channels = []
        _channels = d.pop("channels")
        for channels_item_data in _channels:
            channels_item = SlotInfoChannelsItem.from_dict(channels_item_data)

            channels.append(channels_item)

        serial = d.pop("serial", UNSET)

        slot_info = cls(
            name=name,
            link=link,
            channels=channels,
            serial=serial,
        )

        slot_info.additional_properties = d
        return slot_info

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
