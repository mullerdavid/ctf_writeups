from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="BoardInfoEth")


@attr.s(auto_attribs=True)
class BoardInfoEth:
    """
    Attributes:
        mac (Union[Unset, str]):
        ip (Union[Unset, str]):
        subnet (Union[Unset, str]):
        gateway (Union[Unset, str]):
        dns (Union[Unset, str]):
    """

    mac: Union[Unset, str] = UNSET
    ip: Union[Unset, str] = UNSET
    subnet: Union[Unset, str] = UNSET
    gateway: Union[Unset, str] = UNSET
    dns: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        mac = self.mac
        ip = self.ip
        subnet = self.subnet
        gateway = self.gateway
        dns = self.dns

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if mac is not UNSET:
            field_dict["mac"] = mac
        if ip is not UNSET:
            field_dict["ip"] = ip
        if subnet is not UNSET:
            field_dict["subnet"] = subnet
        if gateway is not UNSET:
            field_dict["gateway"] = gateway
        if dns is not UNSET:
            field_dict["dns"] = dns

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        mac = d.pop("mac", UNSET)

        ip = d.pop("ip", UNSET)

        subnet = d.pop("subnet", UNSET)

        gateway = d.pop("gateway", UNSET)

        dns = d.pop("dns", UNSET)

        board_info_eth = cls(
            mac=mac,
            ip=ip,
            subnet=subnet,
            gateway=gateway,
            dns=dns,
        )

        board_info_eth.additional_properties = d
        return board_info_eth

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
