from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.channel_source import ChannelSource
from ..models.digital_channel_info_type import DigitalChannelInfoType
from ..types import UNSET, Unset

T = TypeVar("T", bound="AnalogChannel")


@attr.s(auto_attribs=True)
class AnalogChannel:
    """
    Attributes:
        type (Union[Unset, DigitalChannelInfoType]):
        id (Union[Unset, int]):
        sources (Union[Unset, List[ChannelSource]]):
        source (Union[Unset, ChannelSource]):
        enabled (Union[Unset, bool]): whether or not the channel data should be returned in the data stream
    """

    type: Union[Unset, DigitalChannelInfoType] = UNSET
    id: Union[Unset, int] = UNSET
    sources: Union[Unset, List[ChannelSource]] = UNSET
    source: Union[Unset, ChannelSource] = UNSET
    enabled: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = self.type.value

        id = self.id
        sources: Union[Unset, List[str]] = UNSET
        if not isinstance(self.sources, Unset):
            sources = []
            for sources_item_data in self.sources:
                sources_item = sources_item_data.value

                sources.append(sources_item)

        source: Union[Unset, str] = UNSET
        if not isinstance(self.source, Unset):
            source = self.source.value

        enabled = self.enabled

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type is not UNSET:
            field_dict["type"] = type
        if id is not UNSET:
            field_dict["id"] = id
        if sources is not UNSET:
            field_dict["sources"] = sources
        if source is not UNSET:
            field_dict["source"] = source
        if enabled is not UNSET:
            field_dict["enabled"] = enabled

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _type = d.pop("type", UNSET)
        type: Union[Unset, DigitalChannelInfoType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = DigitalChannelInfoType(_type)

        id = d.pop("id", UNSET)

        sources = []
        _sources = d.pop("sources", UNSET)
        for sources_item_data in _sources or []:
            sources_item = ChannelSource(sources_item_data)

            sources.append(sources_item)

        _source = d.pop("source", UNSET)
        source: Union[Unset, ChannelSource]
        if isinstance(_source, Unset):
            source = UNSET
        else:
            source = ChannelSource(_source)

        enabled = d.pop("enabled", UNSET)

        analog_channel = cls(
            type=type,
            id=id,
            sources=sources,
            source=source,
            enabled=enabled,
        )

        analog_channel.additional_properties = d
        return analog_channel

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
