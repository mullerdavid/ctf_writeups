#!/usr/bin/env python3

import PySimpleGUI as sg
import numpy as np
import random
import os
import json
import bb_loader as bbl

import frontend_client.models as models

##################################### SAMPLE ##################################

# We need to have a sample for testing purposes.
# Take a sine-wave plus some random noise.
SAMPLE_DATA_SIZE = 100000
SAMPLE_DATA_Y_LIMIS = (0, 255)

SAMPLE_DATA = []

rand = random.Random()
for i in range(SAMPLE_DATA_SIZE):
    SAMPLE_DATA.append(int(np.sin(i/100)*100 + 128 + rand.randint(-5,5)))

print(f"Sample data 1 of size {SAMPLE_DATA_SIZE} created.")

SAMPLE_DATA_2 = []

for i in range(SAMPLE_DATA_SIZE):
    SAMPLE_DATA_2.append(int(np.sin(i/120 + 0.3)*75 + 140 + rand.randint(-10,10)))

print(f"Sample data 2 of size {SAMPLE_DATA_SIZE} crated.")

SAMPLE_DATA_DIGITAL = []
for i in range(SAMPLE_DATA_SIZE):
    SAMPLE_DATA_DIGITAL.append(1 if np.sin(i/60 + 1.337) < 0 else 0)

print(f"Digital sample data for size {SAMPLE_DATA_SIZE} created.")


###############################################################################

SAMPLE_MEMORY_DEPTH = 16*1024*1024

GRAPH_HORIZ_DIV_CNT = 10
GRAPH_VERT_DIV_CNT  = 8

GRAPH_PADDING_VERT = 10
GRAPH_PADDING_LEFT = 10
GRAPH_PADDING_RIGHT = 25

def draw_dashed_line(graph: sg.Graph, start: tuple, end: tuple, color: str, dash_interval: int = 5):
    startvec = np.asarray(start)
    normvec = np.asarray(end) - startvec
    line_length = np.linalg.norm(normvec)
    normvec = normvec * 1/line_length

    length = 0
    state = 1
    while length < line_length:
        if state:
            graph.draw_line(tuple(startvec + length*normvec), tuple(startvec + (length + dash_interval)*normvec), color)
        state = not state
        length += dash_interval


class Trace:
    # An oscilloscope trace.
    data: list          # Graph data (should not be accessed directly to later on support lazy-loading of graph data from device)
    
    graph_color: str    # Canvas graph color
    offset_pos: float   # Offset position on screen in multiples of canvas size
    name: str           # Trace name
    zero_point: int     # The sample value at which "ground" would be located at.
    vert_offset: int    # Vertical screen offset in relative screen height.
    y_scale: float      # Vertial scale in volts/div
    trans_scale: float  # Translation scale in volt / bit
    channel_uid: str    # UniqueID of the correspondig channel

    def __init__(self, data: list, graph_color: str, name: str, zero_point: int, trans_scale: float, channel_uid: str):
        self.data = data
        self.graph_color = graph_color
        self.name = name
        self.zero_point = zero_point
        self.vert_offset = 0
        self.y_scale = 1.0 # V/div
        self.trans_scale = trans_scale
        self.channel_uid = channel_uid

    def get_data_at(self, index: int):
        return self.data[index]
    
    def get_data_length(self):
        return len(self.data)
    
    def get_graph_color(self):
        return self.graph_color
    
class ChannelTrace(Trace):
    connector: bbl.BitBusterConnector
    channel: bbl.BitBusterChannel

    def __init__(self, graph_color: str, channel: bbl.BitBusterChannel, connector: bbl.BitBusterConnector):
        self.channel = channel
        self.graph_color = graph_color
        self.connector = connector

        self.vert_offset = 0.0
        self.y_scale = 1.0
        self.update_scales()

    def update_scales(self):
        if isinstance(self.channel, bbl.BitBusterAnalogChannel):
            voltage_range = self.channel.get_voltage_range()
            self.trans_scale = np.abs(voltage_range[1] - voltage_range[0]) / (2**8)
            self.zero_point = (0 - voltage_range[0]) / self.trans_scale
        elif isinstance(self.channel, bbl.BitBusterDigitalChannel):
            self.trans_scale = 1.0
            self.zero_point = 0.5
        else:
            self.trans_scale = 1.0
            self.zero_point = 0.0

    def get_data_length(self):
        return SAMPLE_MEMORY_DEPTH
    
    def get_graph_color(self):
        return self.graph_color
    
    def get_data_at(self, index: int):
        return self.connector.get_sample_data(self.channel.get_uid(), index)

class TraceViewWindow:
    view_window_center: float   # Relative view window center from 0.0-1.0 in terms of data size
    view_window_size: int       # View window size in number of datapoints.

    def __init__(self, view_window_center: float, view_window_size: int):
        self.view_window_center = view_window_center
        self.view_window_size = view_window_size

class Channel:
    channel_id: int
    channel_name: str
    enabled: bool

    def __init__(self, channel_id: int, channel_name: str):
        self.channel_id = channel_id
        self.channel_name = channel_name
        self.enabled = False

class AnalogChanel(Channel):

    voltage_lower: float
    voltage_higher: float

    def __init__(self, channel_id: int, channel_name: str):
        super().__init__(channel_id, channel_name)
        self.voltage_lower = 0.0
        self.voltage_higher = 1.0

class DigitalChannel(Channel):
    def __init__(self, channel_id: int, channel_name: str):
        super().__init__(channel_id, channel_name)

class Sample:
    # Dataclass for sampling
    sample_rate: float              # Sample-rate in Samples per Second

    def __init__(self, sample_rate: float):
        self.sample_rate = sample_rate

def humanify_unit(value: float, unit: str, decimal_places: int = 1):
    if value >= 1e6:
        return f"%.{decimal_places}f M%s" % (value * 1e-6, unit)
    elif value >= 1e3:
        return f"%.{decimal_places}f k%s" % (value * 1e-3, unit)
    elif value >= 1:
        return f"%.{decimal_places}f %s" % (value, unit)
    elif value >= 1e-3:
        return f"%.{decimal_places}f m%s" % (value * 1e3, unit)
    elif value >= 1e-6:
        return f"%.{decimal_places}f µ%s" % (value * 1e6, unit)
    else:
        return f"%.{decimal_places}f %s" % (value, unit)

def dialog_box(title: str, msg: str):
    win = sg.Window(title, [
        [sg.Text(title)],
        [sg.Text(msg)],
        [sg.Button("OK", key="__btn_ok")]
    ], finalize=True, resizable=False)

    while True:
        evt, _ = win.read()

        if evt == "__btn_ok" or evt == sg.WIN_CLOSED:
            break

    win.close()

class Window:
    window: sg.Window               # The main window handle    
    window_layout: list             # The main window layout structure
    main_graph: sg.Graph            # Main graph
    overview_graph: sg.Graph        # Overview graph (overview slider)
    traces: dict                    # Active traces list
    view_window: TraceViewWindow    # View window configuration settings (the current part of the dump that is viewed)
    
    # Graph viewing settings (timebase, yscale, etc.)
    graph_total_y_height: int       # Graph-y-units total height   
    graph_y_bottom: int             # Graph-y-units bottom
    sample: Sample                  # The current sample handle
    timebase: float                 # Current timebase in seconds / div
    timescale: float                # Sample data timescale in seconds / sample_interval

    trace_dragged: str              # ChannelUID of currently dragged trace, -1 if nothing is currently dragged.
    
    window_cs: sg.Window            # Channel settings window
    window_cs_open: bool
    channels: dict

    valid: bool                     # Flag whether or not the data from the BitBuster is interpreted as valid or not.

    bbl_connector: bbl.BitBusterConnector   # BitBuster loader connector handle/obj

    def __init__(self):
        # Setup window contents.
        self.main_graph = sg.Graph(canvas_size=(700,300), graph_bottom_left=(0,0), graph_top_right=(700,300), background_color="#ffffff", enable_events=True, drag_submits=True, key="graph", expand_x=True, expand_y=True, change_submits=True)
        self.overview_graph = sg.Graph(canvas_size=(700,100), graph_bottom_left=(0,0), graph_top_right=(700,100), background_color="#ffffff", enable_events=True, drag_submits=True, key="graph_overview", expand_x=True, expand_y=False, change_submits=True)

        self.window_layout = [[sg.Column([
            [self.main_graph],
            [self.overview_graph]
        ], expand_x=True, expand_y=True), sg.Column([
            [sg.Frame("Connection", [
                [sg.Text("Host:"), sg.Input("", key="__inp_bbipaddr")],
                [sg.Text("Pass:"), sg.Input("", key="__inp_bbpass")], 
                [sg.Button("Connect", key="__btn_bbconnect")]
            ], expand_x=True)],

            [sg.Frame("Sampling", [
                [sg.Button("Sampling Settings...", key="__btn_channel_settings")],
                [sg.Button("Sample", key="__btn_sample")]
            ], expand_x=True)],

            [sg.Frame("Timebase", [
                [sg.Button("+", key="__btn_timebase_p"), sg.Button("-", key="__btn_timebase_m"), sg.Text("- µs/div", key="__lbl_timebase")]
            ], expand_x=True)],

            [sg.Frame("Analog 0 Scaling", [
                [sg.Button("+", key="__btn_ana0_scale_p"), sg.Button("-", key="__btn_ana0_scale_m"), sg.Text("- V/div", key="__lbl_ana0_scale")]
            ], key="__chcfg_ana0", expand_x=True)],

            [sg.Frame("Analog 1 Scaling", [
                [sg.Button("+", key="__btn_ana1_scale_p"), sg.Button("-", key="__btn_ana1_scale_m"), sg.Text("- V/div", key="__lbl_ana1_scale")]
            ], key="__chcfg_ana1", expand_x=True)],

            [sg.Frame("Save Dump", [
                [sg.Button("Dump...", key="__btn_dump")]
            ])]
        ])]]

        self.window = sg.Window("Window", layout=self.window_layout, margins=(10,10), finalize=True, resizable=True)

        self.window.bind("<Configure>", "evt_configure")
        self.window.TKroot.resizable(True, True)

        # Setup traces and view window
        self.traces = {}
        #self.traces = {
        #    "ana0": Trace(SAMPLE_DATA, "red", "T1", 128, 1.0/100, "ana0"),
        #    "ana1": Trace(SAMPLE_DATA_2, "blue", "T2", 128, 1.0/75, "ana1"),
        #    "dig0": Trace(SAMPLE_DATA_DIGITAL, "green", "D1", 0.5, 1.0, "dig0")
        #}
        self.timescale = 1e-6  # sec/sample
        self.view_window = TraceViewWindow(0.0, 1000)
        self.update_timebase(1e-4) # sec/div

        self.graph_total_y_height = 256+20
        self.graph_y_bottom = -10
        
        self.trace_dragged = ""

        self.valid = False

        # Setup channels
        #self.channels = [
        #    AnalogChanel(0, "Analog 0"),
        #    AnalogChanel(1, "Analog 1"),
        #    *[DigitalChannel(i+2, f"Digital Channel {i+2}") for i in range(28)]
        #]
        self.channels = {}

        # Setup sample
        self.sample = None
        self.timebase = 1e-3 # 1ms/div

        # Init bbl objects (get set at a later time)
        self.bbl_connector = None

        self.window_cs = None
        self.window_cs_open = False

    def update_channels(self):
        self.channels = {}
        self.traces = {}
        colors = ["red", "green", "blue", "orange", "purple", "pink"]
        for i, ch in enumerate(self.bbl_connector.channels):
            if isinstance(ch, bbl.BitBusterAnalogChannel):
                self.channels[f"ana{ch.channel_id}"] = AnalogChanel(ch.channel_id, ch.channel_name)
                self.traces[f"ana{ch.channel_id}"] = ChannelTrace(colors[i % len(colors)], ch, self.bbl_connector)
            elif isinstance(ch, bbl.BitBusterDigitalChannel):
                self.channels[f"dig{ch.channel_id}"] = DigitalChannel(ch.channel_id, ch.channel_name)
                self.traces[f"dig{ch.channel_id}"] = ChannelTrace(colors[i % len(colors)], ch, self.bbl_connector)

    def window_setup(self):
        try:
            with open(f"{os.path.dirname(os.path.realpath(__file__))}/.connection_cache", "r") as cache_file:
                cached_data = json.loads(cache_file.read())

                self.window["__inp_bbipaddr"].update(cached_data['host'])
                self.window["__inp_bbpass"].update(cached_data['password'])
        except:
            pass

        self.render()
        self.update_gui_elements()

    def window_loop(self) -> int:

        if self.window_cs_open:
            return self.channel_window_loop()
        
        event, values = self.window.read()

        if event == "Test":
            print("Test")

        elif event == "evt_configure":
            # consume evt_configure event (gets invoked when window changes)
            pass

        elif event == "graph_overview":
            # graph overview drag or click event.
            # update view window center
            self.view_window.view_window_center = np.clip(values["graph_overview"][0] / self.overview_graph.get_size()[0], 0.0, 1.0)

        elif event == "graph_overview+UP":
            # consume graph_overview mouse button up event.
            pass

        elif event == "graph":
            # see what we want to select.
            mouse_x = values["graph"][0]
            mouse_y = values["graph"][1]

            self.handle_graph_mouse(mouse_x, mouse_y)
            self.render()

            pass

        elif event == "graph+UP":
            self.trace_dragged = ""

        elif event == "__btn_channel_settings":
            # Spawn channel settings window.
            self.spawn_channel_settings_window()

        elif event == "__btn_ana0_scale_m":
            if "ana0" in self.traces:
                self.traces["ana0"].y_scale *= 2
        elif event == "__btn_ana0_scale_p":
            if "ana0" in self.traces:
                self.traces["ana0"].y_scale /= 2
        elif event == "__btn_ana1_scale_m":
            if "ana1" in self.traces:
                self.traces["ana1"].y_scale *= 2
        elif event == "__btn_ana1_scale_p":
            if "ana1" in self.traces:
                self.traces["ana1"].y_scale /= 2

        elif event == "__btn_timebase_p":
            self.update_timebase(self.timebase / 2)
        elif event == "__btn_timebase_m":
            self.update_timebase(self.timebase * 2)

        elif event == "__btn_bbconnect":
            bbip = self.window["__inp_bbipaddr"].get()
            bbpass = self.window["__inp_bbpass"].get()
            print(f"Trying connection to BitBuster at {bbip} with pass {bbpass}...")
            self.bbl_connector = bbl.BitBusterConnector(bbip, bbpass)
            if self.bbl_connector.connect():
                self.bbl_connector.update_info()
                self.update_channels()
                with open(f"{os.path.dirname(os.path.realpath(__file__))}/.connection_cache", "w") as cache_file:
                    cache_file.write(json.dumps({"host": bbip, "password": bbpass}))
            else:
                dialog_box("Error", "Could not connect to a BitBuster with the given IP/password. See console log for more information.")

        elif event == "__btn_sample":
            if self.bbl_connector is not None:
                self.bbl_connector.sample()

                win = sg.Window("Sampling...", [[sg.Text("Waiting for trigger...", key="__lbl_msg")]], finalize=True, resizable=False)
                win.refresh()

                while True:
                    state = "sampling"

                    # Check if still sampling.
                    if state == "sampling" and self.bbl_connector.sampling_done():
                        state = "cache_warmup"
                        win["__lbl_msg"].update("Warming up cache...")
                        win.refresh()

                    if state == "cache_warmup":
                        self.bbl_connector.datacache.cache_warmup()
                        self.valid = True
                        win.refresh()
                        win.close()
                        break

        elif event == "__btn_dump":
            if self.bbl_connector is not None:
                channel_uids = [c.get_uid() for c in self.bbl_connector.channels]
                win = sg.Window("Dumper", [[sg.Text("Channel UID: "), sg.Combo(channel_uids, channel_uids[0], key="__combo_channel")], [sg.Push(), sg.Button("Cancel", key="__btn_cancel"), sg.Input(key="__input_file", enable_events=True, visible=False, do_not_clear=False), sg.FileSaveAs("Dump", key="__fsa_dump", file_types=(("Binary File", ".bin"),), enable_events=True)]], finalize=True, resizable=False)
                
                while True:
                    evt, val = win.read()

                    if evt == "__btn_cancel":
                        win.close()
                        break

                    elif evt == sg.WIN_CLOSED:
                        break

                    elif evt == "__input_file":
                        file = val["__fsa_dump"]
                        chuid = win["__combo_channel"].get()

                        win_info = sg.Window("Dumping...", [[sg.Text("Dump in progress...")], [sg.Text("Loading data. This may take several minutes. Please be patient!", key="__msg")]], finalize=True, resizable=False)

                        if not self.bbl_connector.datacache.is_fully_mapped:
                            self.bbl_connector.datacache.load_from_bitbuster(0, 1, (4*1024*1024))
                            self.bbl_connector.datacache.load_from_bitbuster((4*1024*1024), 1, (4*1024*1024))
                            self.bbl_connector.datacache.load_from_bitbuster((8*1024*1024), 1, (4*1024*1024))
                            self.bbl_connector.datacache.load_from_bitbuster((12*1024*1024), 1, (4*1024*1024))
                            self.bbl_connector.datacache.is_fully_mapped = True

                        win_info["__msg"].update("Packing data...")
                        win_info.refresh()

                        if chuid in self.bbl_connector.datacache[0]:

                            data = [self.bbl_connector.datacache[i][chuid] for i in range(16*1024*1024)]

                            win_info["__msg"].update("Writing to dump file...")
                            win_info.refresh()

                            with open(file, "wb") as dumpfile:
                                dumpfile.write(bytes(data))

                        win_info.close()

        elif event == sg.WIN_CLOSED:
            return 1
        
        else:
            print(event)

        # On theese events, rerender the window graphs, etc..
        #if event == "evt_configure" or event == "graph_overview" or event == "Test":
        self.render()

        self.update_gui_elements()

        return 0
    
    def update_timebase(self, new_timebase: float):
        if new_timebase < 0 or new_timebase > SAMPLE_MEMORY_DEPTH * self.timescale / GRAPH_HORIZ_DIV_CNT:
            return
        self.timebase = new_timebase
        self.view_window.view_window_size = np.clip(int(GRAPH_HORIZ_DIV_CNT * self.timebase / self.timescale), 0, SAMPLE_MEMORY_DEPTH) # divs * (sec/div) / (sec/sample)
    
    def spawn_channel_settings_window(self):
        
        layout = [
            [sg.Text("Channel Settings")]
        ]

        if self.bbl_connector is not None:
            srates_text = [humanify_unit(s, "S/sec", decimal_places=3) for s in self.bbl_connector.sampling_rates]
            channels_text = [c.get_uid() for c in self.bbl_connector.channels]
            trigger_modes = ["Rising", "Falling", "Both"]
            layout.append([sg.Frame("Acquisition", [
                [sg.Text("Sample Memory Depth: "), sg.Text("16 MS")],
                [sg.Text("Sampling Rate: "), sg.Combo(srates_text, srates_text[self.bbl_connector.selected_sampling_rate_idx], key="__combo_sampling_rate")],
                [sg.Checkbox("Enable Trigger", key="__chb_trigen")],
                [sg.Text("Trigger Channel: "), sg.Combo(channels_text, channels_text[0], key="__combo_trig_ch"), sg.Text("Trigger Offset: "), sg.Slider((-2**23+1,2**23-1), default_value=0, resolution=1, expand_x=True, orientation="horizontal", key="__slider_trig_offset")],
                [sg.Text("Trigger Edge Mode: "), sg.Combo(trigger_modes, trigger_modes[0], key="__combo_trig_mode"), sg.Text("Analog Trigger Threshold: "), sg.Slider((0, 255), default_value=127, resolution=1, expand_x=True, orientation="horizontal", key="__slider_trig_thres")]
            ], expand_x=True)])

        frame_cols = []
        frames = []

        for channel in (self.bbl_connector.channels if self.bbl_connector is not None else []):
            channel_uid = channel.get_uid()
            if isinstance(channel, bbl.BitBusterAnalogChannel):
                # Analog channel
                layout.append([sg.Frame(f"{channel.channel_name} ({channel_uid})", [
                    [sg.Text(f"ID: {channel.channel_id}"), sg.Checkbox("Enabled", key=f"__chb_chen_{channel_uid}"), sg.Checkbox("Use External", key=f"__chb_useext_{channel_uid}")],
                    [sg.Text(f"Voltage Range (min-max in Volt)")],
                    [sg.Input("0.0", key=f"__inp_ulow_{channel_uid}"), sg.Text("-"), sg.Input("1.0", key=f"__inp_uhigh_{channel_uid}")]
                ], expand_x=True)])
                
            elif isinstance(channel, bbl.BitBusterDigitalChannel):
                # Digital channel
                frames.append([sg.Frame(f"{channel.channel_name} ({channel_uid})", [
                    [sg.Text(f"ID: {channel.channel_id}"), sg.Checkbox("Enabled", key=f"__chb_chen_{channel_uid}")]
                ], expand_x=True)])

            if len(frames) >= 8:
                frame_cols.append(sg.Column(frames))
                frames = []

        frame_cols.append(sg.Column(frames))

        layout.append([f for f in frame_cols])
        layout.append([sg.Push(), sg.Button("OK", key="__btn_ok")])

        self.window_cs = sg.Window("Channel Settings", layout, resizable=False, finalize=True)

        self.channel_window_update_gui()

        self.window_cs_open = True

    def channel_window_update_gui(self):
        # Update values.
        for channel in (self.bbl_connector.channels if self.bbl_connector is not None else []):
            channel_uid = channel.get_uid()
            self.window_cs[f"__chb_chen_{channel_uid}"].update(channel.enabled)
            if isinstance(channel, bbl.BitBusterAnalogChannel):
                voltage_range = channel.get_voltage_range()
                self.window_cs[f"__inp_ulow_{channel_uid}"].update("%.02f" % (voltage_range[0]))
                self.window_cs[f"__inp_uhigh_{channel_uid}"].update("%.02f" % (voltage_range[1]))

        # Update acquisition
        if self.bbl_connector is not None:
            # Sampling rate
            srates_text = [humanify_unit(s, "S/sec", decimal_places=3) for s in self.bbl_connector.sampling_rates]
            self.window_cs["__combo_sampling_rate"].update(srates_text[self.bbl_connector.selected_sampling_rate_idx])

            # Trigger settings
            self.window_cs["__combo_trig_ch"].update(self.bbl_connector.trigger_channel_uid)
            
            if self.bbl_connector.trigger_mode == models.TriggerConfigurationTrigger.RISING:
                self.window_cs["__combo_trig_mode"].update("Rising")
            elif self.bbl_connector.trigger_mode == models.TriggerConfigurationTrigger.FALLING:
                self.window_cs["__combo_trig_mode"].update("Falling")
            elif self.bbl_connector.trigger_mode == models.TriggerConfigurationTrigger.BOTH:
                self.window_cs["__combo_trig_mode"].update("Both")
            else:
                raise ValueError(f"Invalid trigger mode.")
            
            self.window_cs["__slider_trig_offset"].update(self.bbl_connector.trigger_offset)
            self.window_cs["__slider_trig_thres"].update(self.bbl_connector.trigger_threshold)
            self.window_cs["__chb_trigen"].update(self.bbl_connector.trigger_enabled)

    def channel_window_loop(self):
        event, values = self.window_cs.read()

        if event is None:
            self.window_cs_open = False
            return 0

        if event == "__btn_ok":
            # Update acquisition settings
            if self.bbl_connector is not None:
                srates_text = [humanify_unit(s, "S/sec", decimal_places=3) for s in self.bbl_connector.sampling_rates]
                sampling_rate_sel = self.window_cs["__combo_sampling_rate"].get()

                # Update sampling rate
                for i, s in enumerate(srates_text):
                    if s == sampling_rate_sel:
                        self.bbl_connector.selected_sampling_rate_idx = i

                # Update trigger
                self.bbl_connector.trigger_channel_uid = self.window_cs["__combo_trig_ch"].get()

                trigger_mode_str = self.window_cs["__combo_trig_mode"].get()
                if trigger_mode_str == "Rising":
                    self.bbl_connector.trigger_mode = models.TriggerConfigurationTrigger.RISING
                elif trigger_mode_str == "Falling":
                    self.bbl_connector.trigger_mode = models.TriggerConfigurationTrigger.FALLING
                elif trigger_mode_str == "Both":
                    self.bbl_connector.trigger_mode = models.TriggerConfigurationTrigger.BOTH
                else:
                    raise ValueError(f"Invalid trigger mode. {trigger_mode_str} is not a valid mode.")
                
                self.bbl_connector.trigger_offset = self.window_cs["__slider_trig_offset"].TKScale.get()
                self.bbl_connector.trigger_threshold = self.window_cs["__slider_trig_thres"].TKScale.get()
                self.bbl_connector.trigger_enabled = self.window_cs["__chb_trigen"].get()


            # Update channel settings
            bits_used = 0
            for channel in (self.bbl_connector.channels if self.bbl_connector is not None else []):
                channel_uid = channel.get_uid()
                channel.set_enabled(self.window_cs[f"__chb_chen_{channel_uid}"].get())
                if isinstance(channel, bbl.BitBusterAnalogChannel):
                    if channel.enabled:
                        bits_used += 8
                    try:
                        voltage_lower = float(self.window_cs[f"__inp_ulow_{channel_uid}"].get())
                        voltage_higher = float(self.window_cs[f"__inp_uhigh_{channel_uid}"].get())
                        res = channel.set_voltage_range((voltage_lower, voltage_higher))
                        if not res:
                            dialog_box("Error", f"Hardware cannot satisfy selected voltage range for channel {channel_uid}.")
                            return 0
                    except Exception:
                        dialog_box("Error", f"Invalid value for channel {channel_uid} config")
                        return 0
                    
                    selected_ext = self.window_cs[f"__chb_useext_{channel_uid}"].get()
                    channel.set_selected_source("ext" if selected_ext else "int")
                else:
                    if channel.enabled:
                        bits_used += 1

            if bits_used > 16:
                dialog_box("Error", f"The channel configuration selected is not supported by the BitBuster. A total of 16 sample bits is supported, you selected {bits_used}.")
                return 0
            
            # Download new channel settings to the BitBuster device.
            if self.bbl_connector is not None:
                self.bbl_connector.commit_channel_config()

            self.window_cs_open = False
            self.valid = False

            # update scales for channels.
            if self.bbl_connector is not None:
                for channel in self.bbl_connector.channels:
                    self.traces[channel.get_uid()].channel = channel
                    if isinstance(self.traces[channel.get_uid()], ChannelTrace):
                        self.traces[channel.get_uid()].update_scales()

            self.window_cs.close()

        elif event.startswith("__chb_chen_"):
            pass

        elif event == sg.WIN_CLOSED:
            self.window_cs_open = False

        else:
            print(f"Unknown event: event={event} values={values}")

        return 0
    
    def update_gui_elements(self):
        # Update analog channel volts/div
        for channel_uid, trace in self.traces.items():
            if channel_uid.startswith("ana"):
                self.window[f"__lbl_{channel_uid}_scale"].update(humanify_unit(trace.y_scale, "V/div"))

        self.window["__lbl_timebase"].update(humanify_unit(self.timebase, "s/div"))
    
    def render_graph_geometry(self):
        # Render grid to main graph
        graph_w = self.main_graph.get_size()[0] - GRAPH_PADDING_RIGHT - GRAPH_PADDING_LEFT
        graph_h = self.main_graph.get_size()[1] - (GRAPH_PADDING_VERT * 2)

        graph_y_offset = 0 - (self.main_graph.get_size()[1] - 300) + GRAPH_PADDING_VERT
        graph_x_offset = GRAPH_PADDING_LEFT

        delta_x = graph_w / GRAPH_HORIZ_DIV_CNT
        delta_y = graph_h / GRAPH_VERT_DIV_CNT

        for i in range(GRAPH_VERT_DIV_CNT + 1):
            self.main_graph.draw_line((graph_x_offset,delta_y*i + graph_y_offset), (graph_x_offset + graph_w, delta_y*i + graph_y_offset), color="grey")

        for i in range(GRAPH_HORIZ_DIV_CNT + 1):
            self.main_graph.draw_line((graph_x_offset + i*delta_x, 0 + graph_y_offset), (graph_x_offset + i*delta_x, graph_h + graph_y_offset), color="grey")

    def render_overview_graph(self):
        # Graph size.
        graph_w = self.overview_graph.get_size()[0]
        graph_h = self.overview_graph.get_size()[1]

        if len(self.traces) < 1 or not self.valid:
            return

        # Get the max data size so that we know how large the overview window has to be.
        max_trace_data_len = 0
        for _, trace in self.traces.items():
            if trace.get_data_length() > max_trace_data_len:
                max_trace_data_len = trace.get_data_length()

        # Draw the overview window
        view_window_size_rel = self.view_window.view_window_size / max_trace_data_len
        view_window_slide_size_rel = 1.0 - view_window_size_rel
        self.overview_graph.draw_rectangle(((view_window_slide_size_rel * self.view_window.view_window_center) * graph_w, graph_h), ((view_window_size_rel + view_window_slide_size_rel * self.view_window.view_window_center) * graph_w, 1), fill_color="#cccccc")

        # Draw the traces
        for _, trace in self.traces.items():

            if not trace.channel.enabled:
                continue

            data_sz = trace.get_data_length()
            data_stride = data_sz // 1000
            data_stride_sz = data_sz // data_stride + 1

            def get_data_real_idx(i):
                idx_corr = np.round(i * data_stride)
                grain = data_stride
                if grain >= 16:
                    idx_corr = idx_corr - (idx_corr % 16) # align to cache
                elif grain >= 8:
                    idx_corr = idx_corr - (idx_corr % 8)
                elif grain >= 4:
                    idx_corr = idx_corr - (idx_corr % 4)
                elif grain >= 2:
                    idx_corr = idx_corr - (idx_corr % 2)
                else:
                    #print("unaligned in overview")
                    pass
                if idx_corr >= data_sz:
                    return data_sz-1
                else:
                    return idx_corr        

            graph_total_y_height = self.graph_total_y_height
            graph_bottom_y = self.graph_y_bottom

            delta_x_pt = graph_w / data_stride_sz
            delta_y_pt = graph_h / graph_total_y_height
            y_zero_pt = delta_y_pt * (0 - graph_bottom_y)

            if isinstance(trace.channel, bbl.BitBusterDigitalChannel):
                delta_y_pt *= 200

            # draw the data.
            graph_pts = [(i*delta_x_pt, trace.get_data_at(get_data_real_idx(i))*delta_y_pt + y_zero_pt) for i in range(data_stride_sz)]

            self.overview_graph.draw_lines(graph_pts, color=trace.get_graph_color())

    def render_main_graph(self):
        # Graph size
        graph_w = self.main_graph.get_size()[0] - GRAPH_PADDING_LEFT - GRAPH_PADDING_RIGHT
        graph_h = self.main_graph.get_size()[1] - (GRAPH_PADDING_VERT * 2)

        graph_y_offset = 0 - (self.main_graph.get_size()[1] - 300) + GRAPH_PADDING_VERT
        graph_x_offset = GRAPH_PADDING_LEFT     

        if len(self.traces) < 1 or not self.valid:
            return   

        legend_index = graph_y_offset+5
        legend_delta = 15

        for _, trace in self.traces.items():

            if not trace.channel.enabled:
                continue

            trace_data_len = trace.get_data_length()
            data_lower_idx = int((1 - self.view_window.view_window_size / trace_data_len) * self.view_window.view_window_center * trace_data_len)

            data_sz = self.view_window.view_window_size
            data_stride = data_sz / 1000.0
            data_stride_sz = int(data_sz / data_stride) + 1

            def get_data_real_idx(i):
                idx_corr = int(i * data_stride) + data_lower_idx
                grain = data_stride / 2
                if grain >= 16:
                    idx_corr = idx_corr - (idx_corr % 16) # align to cache
                elif grain >= 8:
                    idx_corr = idx_corr - (idx_corr % 8)
                elif grain >= 4:
                    idx_corr = idx_corr - (idx_corr % 4)
                elif grain >= 2:
                    idx_corr = idx_corr - (idx_corr % 2)
                else:
                    pass
                    #print("unaligned in main")
                if idx_corr >= trace_data_len:
                    return trace_data_len-1
                else:
                    return idx_corr

            value_delta_x = graph_w / data_stride_sz

            zero_point_y = (trace.vert_offset + 0.5) * graph_h # Here is zero in pixels @ screen
            value_delta_y = trace.trans_scale / trace.y_scale * (graph_h / GRAPH_VERT_DIV_CNT)

            # Draw trace
            if isinstance(trace.channel, bbl.BitBusterAnalogChannel):
                # Draw graph
                graph_pts = [(graph_x_offset + i*value_delta_x, (trace.get_data_at(get_data_real_idx(i)) - 127) * value_delta_y + zero_point_y + graph_y_offset) for i in range(data_stride_sz)]
                self.main_graph.draw_lines(graph_pts, color=trace.get_graph_color(), width=1.5)

                draw_dashed_line(self.main_graph, (graph_x_offset, (255 - 127)*value_delta_y + zero_point_y + graph_y_offset), (graph_x_offset+graph_w, (255 - 127)*value_delta_y + zero_point_y + graph_y_offset), color=trace.get_graph_color())
                draw_dashed_line(self.main_graph, (graph_x_offset, (0   - 127)*value_delta_y + zero_point_y + graph_y_offset), (graph_x_offset+graph_w, (0   - 127)*value_delta_y + zero_point_y + graph_y_offset), color=trace.get_graph_color())

                voltage_range = trace.channel.get_voltage_range()
                self.main_graph.draw_text(humanify_unit(voltage_range[1], "V", decimal_places=3), (graph_x_offset + graph_w - 5, (255 - 127)*value_delta_y + 5 + zero_point_y + graph_y_offset), color=trace.get_graph_color(), text_location=sg.TEXT_LOCATION_BOTTOM_RIGHT)
                self.main_graph.draw_text(humanify_unit(voltage_range[0], "V", decimal_places=3), (graph_x_offset + graph_w - 5, (0   - 127)*value_delta_y - 5 + zero_point_y + graph_y_offset), color=trace.get_graph_color(), text_location=sg.TEXT_LOCATION_TOP_RIGHT)

                self.main_graph.draw_text(f"{trace.channel.channel_name} ({trace.channel.get_uid()})", (graph_x_offset+5, legend_index), color=trace.get_graph_color(), text_location=sg.TEXT_LOCATION_BOTTOM_LEFT)
                legend_index += legend_delta

                trace_gnd_y = (127 - 127)*value_delta_y + zero_point_y + graph_y_offset
            elif isinstance(trace.channel, bbl.BitBusterDigitalChannel):
                # Draw graph
                graph_pts = [(graph_x_offset + i*value_delta_x, (trace.get_data_at(get_data_real_idx(i)) - trace.zero_point) * value_delta_y + zero_point_y + graph_y_offset) for i in range(data_stride_sz)]
                self.main_graph.draw_lines(graph_pts, color=trace.get_graph_color(), width=1.5)

                self.main_graph.draw_text(f"{trace.channel.channel_name} ({trace.channel.get_uid()})", (graph_x_offset+5, legend_index), color=trace.get_graph_color(), text_location=sg.TEXT_LOCATION_BOTTOM_LEFT)
                legend_index += legend_delta

                trace_gnd_y = (0.5 - trace.zero_point)*value_delta_y + zero_point_y + graph_y_offset
            else:
                # Draw graph
                graph_pts = [(graph_x_offset + i*value_delta_x, (trace.get_data_at(get_data_real_idx(i)) - trace.zero_point) * value_delta_y + zero_point_y + graph_y_offset) for i in range(data_stride_sz)]
                self.main_graph.draw_lines(graph_pts, color=trace.get_graph_color(), width=1.5)

                self.main_graph.draw_text(f"{trace.channel.channel_name} ({trace.channel.get_uid()})", (graph_x_offset+5, legend_index), color=trace.get_graph_color(), text_location=sg.TEXT_LOCATION_BOTTOM_LEFT)
                legend_index += legend_delta

                trace_gnd_y = np.clip(zero_point_y + graph_y_offset, graph_y_offset, graph_y_offset + graph_h)

            # Draw trace ground point.
            size = 7
            base_pt = np.array([graph_x_offset + graph_w + 10, trace_gnd_y])
            self.main_graph.draw_polygon([tuple(base_pt + np.array([size*np.cos(i*2*np.pi/3 + np.pi),size*np.sin(i*2*np.pi/3 + np.pi)])) for i in range(3)],
                                         fill_color=trace.get_graph_color())
            
        # Whitespace at top and bottom
        self.main_graph.draw_rectangle((graph_x_offset, graph_y_offset-1), (graph_x_offset + graph_w, graph_y_offset - GRAPH_PADDING_VERT), fill_color="white", line_width=0)
        self.main_graph.draw_rectangle((graph_x_offset, self.main_graph.get_size()[1]), (graph_x_offset + graph_w, graph_y_offset + graph_h), fill_color="white", line_width=0)
    
    def render(self):
        # Erase graphs
        self.overview_graph.erase()
        self.main_graph.erase()

        # Render all traces to the main graph view.
        self.render_graph_geometry()
        self.render_overview_graph()
        self.render_main_graph()

    def handle_graph_mouse(self, mouse_x: int, mouse_y: int):
        # Graph size
        graph_w = self.main_graph.get_size()[0] - GRAPH_PADDING_LEFT - GRAPH_PADDING_RIGHT
        graph_h = self.main_graph.get_size()[1] - (GRAPH_PADDING_VERT * 2)

        graph_y_offset = 0 - (self.main_graph.get_size()[1] - 300) + GRAPH_PADDING_VERT
        graph_x_offset = GRAPH_PADDING_LEFT

        if self.trace_dragged != "":
            self.traces[self.trace_dragged].vert_offset = np.clip((mouse_y - graph_y_offset - graph_h/2) / graph_h, -0.5, 0.5)

        if mouse_x >= graph_x_offset + graph_w and mouse_x <= self.main_graph.get_size()[0] and self.trace_dragged == "":
            # Bounding box of trace ground points
            trace_y_box_padding = 10            

            for channel_uid, trace in self.traces.items():
                if not trace.channel.enabled:
                    continue
                zero_point_y = (trace.vert_offset + 0.5) * graph_h # Here is zero in pixels @ screen
                value_delta_y = trace.trans_scale / trace.y_scale * (graph_h / GRAPH_VERT_DIV_CNT)
                if isinstance(trace.channel, bbl.BitBusterAnalogChannel):
                    trace_gnd_y = (127 - 127)*value_delta_y + zero_point_y + graph_y_offset
                elif isinstance(trace.channel, bbl.BitBusterDigitalChannel):
                    trace_gnd_y = (0.5 - trace.zero_point)*value_delta_y + zero_point_y + graph_y_offset
                else:
                    trace_gnd_y = np.clip(zero_point_y + graph_y_offset, graph_y_offset, graph_y_offset + graph_h)
                trace_y = trace_gnd_y # np.clip(zero_point_y + graph_y_offset, graph_y_offset, graph_y_offset + graph_h)
                if mouse_y >= trace_y - trace_y_box_padding and mouse_y <= trace_y + trace_y_box_padding:
                    trace.vert_offset = np.clip((mouse_y - graph_y_offset - graph_h/2) / graph_h, -0.5, 0.5)
                    self.trace_dragged = channel_uid
                    break

def usage():
    print("./main.py")

def main():

    if False:
        usage()
        return -1

    window = Window()

    window.window_setup()

    while True:
        wl_stat = window.window_loop()

        if wl_stat != 0:
            return wl_stat

    return 0

if __name__ == "__main__":
    exit(main())
